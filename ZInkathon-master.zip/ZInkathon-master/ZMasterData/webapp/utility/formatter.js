jQuery.sap.declare("inc.inkt.od.ZMasterData.utility.formatter");
inc.inkt.od.ZMasterData.utility.formatter = {

	checkEmail: function (sEmail) {
		this.removeStyleClass("borderRed");
		console.log(sEmail)
		var mailregex = /^([a-zA-Z0-9\.-_]+)@([a-zA-Z0-9-]+)\.([a-z]{2,15})(\.[a-z]{2,15})?$/;

		if (!mailregex.test(sEmail)) {
			this.addStyleClass("borderRed");
			// MessageToast.show("Email is Invalid");
		
			// oDataModel.setProperty("/error", "Error");
		
		} else {
			this.removeStyleClass("borderRed");
			
		}
	}

};