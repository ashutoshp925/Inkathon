sap.ui.define([
	"sap/m/MessageToast",
	"sap/ui/core/mvc/Controller",
	"sap/base/Log"
], function (MessageToast, Controller, Log) {
	"use strict";

	return Controller.extend("inc.inkt.od.ZMasterData.controller.BaseController", {

		onInit: function () {
			


			this.getSplitAppObj().setHomeIcon({
				'phone': 'phone-icon.png',
				'tablet': 'tablet-icon.png',
				'icon': 'desktop.ico'
			});
		
		},
		
		onOrientationChange: function (oEvent) {
			var bLandscapeOrientation = oEvent.getParameter("landscape"),
				sMsg = "Orientation now is: " + (bLandscapeOrientation ? "Landscape" : "Portrait");
			MessageToast.show(sMsg, {
				duration: 5000
			});
		},

		onPressNavToDetail: function () {
			this.getSplitAppObj().to(this.createId("detailDetail"));
		},

		onPressDetailBack: function () {
			this.getSplitAppObj().backDetail();
		},

		onPressMasterBack: function () {
			this.getSplitAppObj().backMaster();
		},

		onPressGoToMaster: function () {
			this.getSplitAppObj().toMaster(this.createId("master2"));
		},

		onListItemPress: function (oEvent) {
			var sToPageId = oEvent.getParameter("listItem").getCustomData()[0].getValue();

			this.getSplitAppObj().toDetail(this.createId(sToPageId));
		},

		onPressModeBtn: function (oEvent) {
			var sSplitAppMode = oEvent.getSource().getSelectedButton().getCustomData()[0].getValue();

			this.getSplitAppObj().setMode(sSplitAppMode);
			MessageToast.show("Split Container mode is changed to: " + sSplitAppMode, {
				duration: 5000
			});
		},

		getSplitAppObj: function () {
			var result = this.byId("SplitAppDemo");
			
			// var iPno = oDataModel.getProperty("/identifications/personnelNo");
			// console.log(typeof iPno);
			// iPno=iPno?parseInt(iPno):null;
			// oDataModel.setProperty("/identifications/personnelNo", iPno);

			// var iTel = oDataModel.getProperty("/communications/telephone");
			// iTel=iTel?parseInt(iTel):null;
			// oDataModel.setProperty("/communications/telephone", iTel);

			// var iFax = oDataModel.getProperty("/communications/fax");
			// iFax=iFax?parseInt(iFax):null;
			// oDataModel.setProperty("/communications/fax", iFax);

			// var iMobile = oDataModel.getProperty("/communications/mobile");
			// iMobile=iMobile?parseInt(iMobile):null;
			// oDataModel.setProperty("/communications/mobile", iMobile);

			// var iExt = oDataModel.getProperty("/communications/extAddress");
			// iExt=iExt?parseInt(iExt):null;
			// oDataModel.setProperty("/communications/extAddress", iExt);

			// for (var i = 0; i < addr.length; i++) {
			// 	var postal = oDataModel.getProperty("/address/" + i + "/postalCode");
			// 	postal=postal?parseInt(postal):null;
			// 	oDataModel.setProperty("/address/" + i + "/postalCode", parseInt(postal));

			// 	var tel = oDataModel.getProperty("/address/" + i + "/telephone");
			// 	oDataModel.setProperty("/address/" + i + "/telephone", parseInt(tel));

			// }
			if (!result) {
				Log.info("SplitApp object can't be found");
			}
			return result;
		}

	});
});