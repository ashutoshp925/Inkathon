sap.ui.define([
	"sap/m/MessageToast",
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/base/Log",
	"inc/inkt/od/ZMasterData/controller/BaseController",
	"../utility/formatter",
	"sap/ui/core/Fragment",
	"sap/ui/core/UIComponent",
	"sap/ui/core/BusyIndicator"
], function (MessageToast, Controller, JSONModel, Log, BaseController, formatter, Fragment, UIComponent, BusyIndicator) {
	"use strict";

	return BaseController.extend("inc.inkt.od.ZMasterData.controller.HomeView", {
		formatter: formatter,
		myToken: "",
		onInit: function () {
			var that = this;
			BusyIndicator.show(0);
			// this.showBusyIndicator(8000,2000);
			var oDataModel = this.getOwnerComponent().getModel("oDataModel");
			var oBasicData = {};
			var oAddress = [];
			var oPayment = [];
			var oCreateComm = this.createComm();
			var oIdentification = this.createIdent();

			oDataModel.setProperty("/basicDetails", oBasicData);
			oDataModel.setProperty("/address", oAddress);
			oDataModel.setProperty("/payment", oPayment);
			oDataModel.setProperty("/identifications", oIdentification);
			oDataModel.setProperty("/communications", oCreateComm);

			var oJavaGlobalModel = this.getOwnerComponent().getModel("oJavaGlobalModel");
			var oDisplayGlobalModel = this.getOwnerComponent().getModel("oDisplayGlobalModel");
			var oUpdateGlobalModel = this.getOwnerComponent().getModel("oUpdateGlobalModel");
			// oJavaGlobalModel.setBusy(true);
			var oOrderData = {

				"sSelectedKeyOrder": "Ascending",

				"aOrderList": [{
					"sOrder": "Ascending"
				}, {
					"sOrder": "Descending"
				}]

			};

			var oOrderModel = new sap.ui.model.json.JSONModel(oOrderData);
			this.getView().setModel(oOrderModel, "oOrderModel");

			var oSortData = {

				"sSelectedKeySort": "BP ID"

			};

			var oSortModel = new sap.ui.model.json.JSONModel(oSortData);
			this.getView().setModel(oSortModel, "oSortModel");

			var oSearchData = {

				"sSelectedKeySearch": "Business Partner ID",

				"aSearchList": [{
					"sSearch": "Business Partner ID"
				}, {
					"sSearch": "First Name"
				}, {
					"sSearch": "Last Name"
				}, {
					"sSearch": "Role ID"
				}]

			};

			var oSearchModel = new sap.ui.model.json.JSONModel(oSearchData);
			this.getView().setModel(oSearchModel, "oSearchModel");

			var oDisplaySortModel = this.getView().getModel("oSortModel");
			var pS = 8;
			var oEditData = true;
			var oEnabledata = true;
			var oEditGlobalModel = this.getOwnerComponent().getModel("oEditGlobalModel");
			oEditGlobalModel.setProperty("/editProperty", oEditData);
			oEditGlobalModel.setProperty("/enableProperty", oEnabledata);
			oEditGlobalModel.setProperty("/pageSize", pS);

			var size = oDisplayGlobalModel.iSizeLimit;
			oDisplayGlobalModel.setSizeLimit(1000);
			oJavaGlobalModel.setSizeLimit(1000);
			var size1 = oDisplayGlobalModel.iSizeLimit;
			console.log(size);
			console.log(size1);

			var sDisplayBasicUrl = "/Service_Lookups/find/basicData";
			$.ajax({
				url: sDisplayBasicUrl,
				type: "GET",
				async: true,
				contentType: "application/json",
				success: function (results, status, xhr) {
					console.log(results);
					oDisplayGlobalModel.setProperty("/basicData", results);
					console.log(oDisplayGlobalModel);
				},
				error: function (e) {
					console.log(e);
				}
			});

			var sLangUrl = "/Service_Lookups/api/languages";
			$.ajax({
				url: sLangUrl,
				type: "GET",
				async: true,
				contentType: "application/json",
				// beforeSend: function (xhr) {
				// 	sap.ui.core.BusyIndicator.show(7000);
				// 	// xhr.setRequestHeader("X-CSRF-Token", "Fetch");
				// },

				success: function (results, status, xhr) {
					console.log(results);
					oJavaGlobalModel.setProperty("/language", results);
					oUpdateGlobalModel.setProperty("/language", results);
					console.log(oJavaGlobalModel);
					sap.ui.core.BusyIndicator.hide();
				},
				error: function (e) {
					console.log(e);
				}
			});

			var sCountryUrl = "/Service_Lookups/api/countries";
			$.ajax({
				url: sCountryUrl,
				type: "GET",
				async: true,
				contentType: "application/json",
				success: function (results, status, xhr) {
					console.log(results);
					oJavaGlobalModel.setProperty("/countries", results);
					oUpdateGlobalModel.setProperty("/countries", results);
					console.log(oJavaGlobalModel);
				},
				error: function (e) {
					console.log(e);
				}
			});

			var sReference = "/Service_Lookups/api/reference";
			$.ajax({
				url: sReference,
				type: "GET",
				async: true,
				contentType: "application/json",
				success: function (results, status, xhr) {
					console.log(results);
					oJavaGlobalModel.setProperty("/reference", results);
					oUpdateGlobalModel.setProperty("/reference", results);
					console.log(oJavaGlobalModel);
				},
				error: function (e) {
					console.log(e);
				}
			});

			var sMaritalStatusUrl = "/Service_Lookups/api/maritalstatus";
			$.ajax({
				url: sMaritalStatusUrl,
				type: "GET",
				async: true,
				contentType: "application/json",
				success: function (results, status, xhr) {
					console.log(results);
					oJavaGlobalModel.setProperty("/maritalStatus", results);
					oUpdateGlobalModel.setProperty("/maritalStatus", results);
					console.log(oJavaGlobalModel);
				},
				error: function (e) {
					console.log(e);
				}
			});

			var sOccupationUrl = "/Service_Lookups/api/occupation";
			$.ajax({
				url: sOccupationUrl,
				type: "GET",
				async: true,
				contentType: "application/json",
				success: function (results, status, xhr) {
					console.log(results);
					oJavaGlobalModel.setProperty("/occupation", results);
					oUpdateGlobalModel.setProperty("/occupation", results);
					console.log(oJavaGlobalModel);
				},
				error: function (e) {
					console.log(e);
				}
			});

			var sBusinessRoleUrl = "/Service_Lookups/api/businessRoles";
			$.ajax({
				url: sBusinessRoleUrl,
				type: "GET",
				async: true,
				contentType: "application/json",
				success: function (results, status, xhr) {
					console.log(results);
					oJavaGlobalModel.setProperty("/businessRoles", results);
					oUpdateGlobalModel.setProperty("/businessRoles", results);
					console.log(oJavaGlobalModel);
				},
				error: function (e) {
					console.log(e);
				}
			});
			var sNationalityUrl = "/Service_Lookups/api/nationality";
			$.ajax({
				url: sNationalityUrl,
				type: "GET",
				async: true,
				contentType: "application/json",
				success: function (results, status, xhr) {
					console.log(results);
					oJavaGlobalModel.setProperty("/nationality", results);
					oUpdateGlobalModel.setProperty("/nationality", results);
					console.log(oJavaGlobalModel);
				},
				error: function (e) {
					console.log(e);
				}
			});
			var sDisplayUrl = "/Service_Lookups/api/searchParameter";
			$.ajax({
				url: sDisplayUrl,
				type: "GET",
				async: true,
				contentType: "application/json",
				success: function (results, status, xhr) {
					console.log(results);
					oDisplaySortModel.setProperty("/displayLookup", results);
					console.log(oDisplaySortModel);
				},
				error: function (e) {
					console.log(e);
				}
			});

			var sStdCommMethoUrl = "/Service_Lookups/api/standCommMethod";
			$.ajax({
				url: sStdCommMethoUrl,
				type: "GET",
				async: true,
				contentType: "application/json",
				headers: {
					"x-CSRF-Token": "Fetch"
				},
				success: function (results, status, response) {
					BusyIndicator.hide();
					console.log(results);
					oJavaGlobalModel.setProperty("/standCommMethod", results);
					oUpdateGlobalModel.setProperty("/standCommMethod", results);
					console.log(oJavaGlobalModel);
					console.log(oUpdateGlobalModel);
					that.myToken = response.getResponseHeader("x-csrf-token");
					console.log(that.myToken);

				},
				error: function (e) {
					BusyIndicator.hide();
					console.log(e);
				}
			});
			// BusyIndicator.show(7000);
			// BusyIndicator.hide();
			// display

		},

		getRouter: function () {
			return UIComponent.getRouterFor(this);
		},

		flag: 0,
		totalPage: 0,
		searchTotalPage: 0,
		sortTotalPage: 0,

		searchPageUrl: "",
		clicks: 0,
		searchClicks: 0,
		sortClicks: 0,

		pageSize: 8,

		onPageSize: function () {
			var that = this;
			that.pageSize = this.getOwnerComponent().getModel("oEditGlobalModel").getProperty("/pageSize");
			var pFlag = this.flag;
			if (pFlag === 0) {
				that.fnPagination();
			} else if (pFlag === 1) {
				that.onSort();
			} else if (pFlag === 2) {
				that.onSearch();
			} else if (pFlag === 3) {
				that.onFilter();
			} else if (pFlag === 4) {
				that.onGoto();
			}

		},

		fnPagination: function () {
			BusyIndicator.show(0);
			this.flag = 0;
			var that = this;
			var sDisplaySortModel = this.getView().getModel("oSortModel");
			var sSelectedkeySort = sDisplaySortModel.getProperty("/sSelectedKeySort");

			var oJavaGlobalModel = this.getOwnerComponent().getModel("oJavaGlobalModel");
			var totalData;
			var sPagination;

			var pageSize = that.pageSize;

			var pageNo = that.clicks;

			sPagination = "/Service_Lookups/find/page?orderBy=&pno=" + pageNo + "&psize=" + pageSize + "&sortParam=";

			$.ajax({
				url: sPagination,
				type: "GET",
				dataType: "json",
				async: true,
				success: function (data, textStatus, jqXHR) {
					BusyIndicator.hide();
					// var len = data.length;
					console.log(data.listBusinessPartner);
					totalData = data.listBusinessPartner;
					that.totalPage = data.totalPage;
					oJavaGlobalModel.setProperty("/listBusinessPartner", data.listBusinessPartner);
					console.log(that.totalPage);
					oJavaGlobalModel.setProperty("/totalPages", that.totalPage);

					oJavaGlobalModel.setProperty("/currentPage", pageNo + 1);

				},
				error: function (jqXHR, textStatus, errorThrown) {
					BusyIndicator.hide();
					MessageToast.show("Oh no, an error occurred");
				}
			});

			return totalData;
		},
		onChange: function (oEvent) {
			var sQuery = oEvent.getParameter("value");
			if (sQuery === "" || sQuery === undefined) {
				oEvent.getSource().setValueState(sap.ui.core.ValueState.Error); // if the field is empty after change, it will go red
			} else {
				oEvent.getSource().setValueState(sap.ui.core.ValueState.None); // if the field is not empty after change, the value state (if any) is removed
			}
		},
		onSort: function () {
			BusyIndicator.show(0);
			this.flag = 1;
			var sModel = this.getView().getModel("oOrderModel");
			var sSelectedkeyOrder = sModel.getProperty("/sSelectedKeyOrder");
			var sDisplaySortModel = this.getView().getModel("oSortModel");
			var sSelectedkeySort = sDisplaySortModel.getProperty("/sSelectedKeySort");
			// console.log(sSelectedkeyOrder);
			var that = this;
			var oJavaGlobalModel = this.getOwnerComponent().getModel("oJavaGlobalModel");
			var totalData;
			var sPagination;

			console.log(sSelectedkeyOrder);
			var pageNo = that.sortClicks;

			var pageSize = that.pageSize;
			if (sSelectedkeySort === "BP ID") {
				if (sSelectedkeyOrder === "Ascending") {
					sPagination = "/Service_Lookups/find/page?orderBy=" + sSelectedkeyOrder + "&pno=" + pageNo + "&psize=" + pageSize +
						"&sortParam=bpId";
				} else {
					sPagination = "/Service_Lookups/find/page?orderBy=" + sSelectedkeyOrder + "&pno=" + pageNo +
						"&psize=" + pageSize + "&sortParam=bpId";
				}
			} else if (sSelectedkeySort === "First Name") {
				if (sSelectedkeyOrder === "Ascending") {
					sPagination = "/Service_Lookups/find/page?orderBy=" + sSelectedkeyOrder + "&pno=" + pageNo +
						"&psize=" + pageSize + "&sortParam=firstName";
				} else {

					sPagination = "/Service_Lookups/find/page?orderBy=" + sSelectedkeyOrder + "&pno=" + pageNo +
						"&psize=" + pageSize + "&sortParam=firstName";
				}
			} else if (sSelectedkeySort === "Last Name") {
				if (sSelectedkeyOrder === "Ascending") {
					sPagination = "/Service_Lookups/find/page?orderBy=" + sSelectedkeyOrder + "&pno=" + pageNo +
						"&psize=" + pageSize + "&sortParam=lastName";
				} else {
					sPagination = "/Service_Lookups/find/page?orderBy=" + sSelectedkeyOrder + "&pno=" + pageNo +
						"&psize=" + pageSize + "&sortParam=lastName";
				}
			} else {
				if (sSelectedkeyOrder === "Ascending") {
					sPagination = "/Service_Lookups/find/page?orderBy=" + sSelectedkeyOrder + "&pno=" + pageNo +
						"&psize=" + pageSize + "&sortParam=roleId";
				} else {
					sPagination = "/Service_Lookups/find/page?orderBy=" + sSelectedkeyOrder + "&pno=" + pageNo +
						"&psize=" + pageSize + "&sortParam=roleId";
				}
			}

			$.ajax({
				url: sPagination,
				dataType: "json",
				type: "GET",
				async: true,
				success: function (data, textStatus, jqXHR) {
					BusyIndicator.hide();
					// var len = data.length;
					console.log(data.listBusinessPartner);
					totalData = data.listBusinessPartner;
					that.sortTotalPage = data.totalPage;
					oJavaGlobalModel.setProperty("/listBusinessPartner", data.listBusinessPartner);
					console.log(that.sortTotalPage);
					oJavaGlobalModel.setProperty("/totalPages", that.sortTotalPage);

					oJavaGlobalModel.setProperty("/currentPage", pageNo + 1);
				},
				error: function (error) {
					BusyIndicator.hide();
					MessageToast.show("Oh no, an error occurred");
					console.log(error);
				}
			});

			return totalData;
		},

		onSearch: function () {
			BusyIndicator.show(0);
			this.flag = 2;
			var oJavaGlobalModel = this.getOwnerComponent().getModel("oJavaGlobalModel");
			var sSearchModel = this.getView().getModel("oSearchModel");
			var sSelectedkeySearch = sSearchModel.getProperty("/sSelectedKeySearch");
			var selectedItems = oJavaGlobalModel.getProperty("/filterQuery");

			if (selectedItems === undefined) {
				var len = 0;
			} else {
				len = selectedItems.length;
			}

			// var sQuery = oEvent.getSource().getValue();
			// console.log(sQuery);

			var sQuery = sSearchModel.getProperty("/searchQuery");
			var that = this;
			var bpIdDefault = "BP ID";
			var orderDefault = "Ascending";
			// oJavaGlobalModel.setProperty("/searchParam", sQuery);
			var totalData;
			var sPagination;
			var pageNo = 0;
			// this.clicks = 0;
			if (sQuery === "" || sQuery === undefined) {
				if (len === 0 || len === 2) {
					sPagination = "/Service_Lookups/find/page?orderBy=Ascending&pno=" + pageNo + "&psize=" + that.pageSize + "&sortParam=bpId";
				} else if (len === 1) {
					var sQueryFilter = selectedItems[0];
					if (sQueryFilter === "Customer") {
						sPagination = "/Service_Lookups/find/findByRole?pno=" + pageNo + "&psize=" + that.pageSize + "&role=Customer";

					} else if (sQueryFilter === "Vendor") {
						sPagination = "/Service_Lookups/find/findByRole?pno=" + pageNo + "&psize=" + that.pageSize + "&role=Vendor";
					}
				}
				this.getView().getModel("oSortModel").setProperty("/sSelectedKeySort", bpIdDefault);
				this.getView().getModel("oOrderModel").setProperty("/sSelectedKeyOrder", orderDefault);
			} else {
				if (len === 0 || len === 2) {
					if (sSelectedkeySearch === "Business Partner ID") {
						sPagination = "/Service_Lookups/find/findByBusinessId?bpRole=&bpId=" + sQuery + "&pno=" + pageNo + "&psize=" + that.pageSize +
							"";
					} else if (sSelectedkeySearch === "First Name") {
						sPagination = "/Service_Lookups/find/findByFirstName?bpRole=&firstName=" + sQuery + "&pno=" + pageNo + "&psize=" + that.pageSize +
							"";
					} else if (sSelectedkeySearch === "Last Name") {
						sPagination = "/Service_Lookups/find/findByLastName?bpRole=&lastName=" + sQuery + "&pno=" + pageNo + "&psize=" + that.pageSize +
							"";
					} else {
						sPagination = "/Service_Lookups/find/findByRoleId?bpRole=&pno=" + pageNo + "&psize=" + that.pageSize + "&roleId=" + sQuery;
					}
				} else if (len === 1) {
					sQueryFilter = selectedItems[0];
					if (sQueryFilter === "Customer") {
						if (sSelectedkeySearch === "Business Partner ID") {
							sPagination = "/Service_Lookups/find/findByBusinessId?bpRole=Customer&bpId=" + sQuery + "&pno=" + pageNo + "&psize=" + that.pageSize +
								"";
						} else if (sSelectedkeySearch === "First Name") {
							sPagination = "/Service_Lookups/find/findByFirstName?bpRole=Customer&firstName=" + sQuery + "&pno=" + pageNo + "&psize=" + that
								.pageSize + "";
						} else if (sSelectedkeySearch === "Last Name") {
							sPagination = "/Service_Lookups/find/findByLastName?bpRole=Customer&lastName=" + sQuery + "&pno=" + pageNo + "&psize=" + that.pageSize +
								"";
						} else {
							sPagination = "/Service_Lookups/find/findByRoleId?bpRole=Customer&pno=" + pageNo + "&psize=" + that.pageSize + "&roleId=" +
								sQuery;
						}

					} else if (sQueryFilter === "Vendor") {
						if (sSelectedkeySearch === "Business Partner ID") {
							sPagination = "/Service_Lookups/find/findByBusinessId?bpRole=Vendor&bpId=" + sQuery + "&pno=" + pageNo + "&psize=" + that.pageSize +
								"";
						} else if (sSelectedkeySearch === "First Name") {
							sPagination = "/Service_Lookups/find/findByFirstName?bpRole=Vendor&firstName=" + sQuery + "&pno=" + pageNo + "&psize=" + that.pageSize +
								"";
						} else if (sSelectedkeySearch === "Last Name") {
							sPagination = "/Service_Lookups/find/findByLastName?bpRole=Vendor&lastName=" + sQuery + "&pno=" + pageNo + "&psize=" + that.pageSize +
								"";
						} else {
							sPagination = "/Service_Lookups/find/findByRoleId?bpRole=Vendor&pno=" + pageNo + "&psize=" + that.pageSize + "&roleId=" +
								sQuery;
						}
					}
				}
			}
			this.searchPageUrl = sPagination;
			$.ajax({
				url: sPagination,
				dataType: "json",
				type: "GET",
				async: true,
				success: function (data, textStatus, jqXHR) {
					BusyIndicator.hide();
					// var len = data.length;
					console.log(data.listBusinessPartner);
					totalData = data.listBusinessPartner;
					that.searchTotalPage = data.totalPage;
					oJavaGlobalModel.setProperty("/listBusinessPartner", data.listBusinessPartner);
					console.log(that.searchTotalPage);
					that.byId("previous").setEnabled(false);
					if (that.searchTotalPage === 1) {
						that.byId("next").setEnabled(false);
						that.byId("previous").setEnabled(false);
						oJavaGlobalModel.setProperty("/totalPages", that.searchTotalPage);
						oJavaGlobalModel.setProperty("/currentPage", pageNo + 1);
					} else if (that.searchTotalPage === 0) {
						that.byId("next").setEnabled(false);
						that.byId("previous").setEnabled(false);
						oJavaGlobalModel.setProperty("/totalPages", that.searchTotalPage);
						oJavaGlobalModel.setProperty("/currentPage", 0);

					} else {
						that.byId("next").setEnabled(true);
						oJavaGlobalModel.setProperty("/totalPages", that.searchTotalPage);
						oJavaGlobalModel.setProperty("/currentPage", pageNo + 1);
					}

				},
				error: function (jqXHR, textStatus, errorThrown) {
					BusyIndicator.hide();
					MessageToast.show("Oh no, an error occurred");
				}
			});

			that.searchClicks = 0;

			return totalData;
		},
		onSearchPagination: function (sQuery) {
			BusyIndicator.show(0);
			var oJavaGlobalModel = this.getOwnerComponent().getModel("oJavaGlobalModel");
			var sSearchModel = this.getView().getModel("oSearchModel");
			var sSelectedkeySearch = sSearchModel.getProperty("/sSelectedKeySearch");

			var selectedItems = oJavaGlobalModel.getProperty("/filterQuery");

			if (selectedItems === undefined) {
				var len = 0;
			} else {
				len = selectedItems.length;
			}

			console.log(sQuery);
			var that = this;

			var totalData;
			var sPagination;
			var pageNo = that.searchClicks;

			if (sQuery === "" || sQuery === undefined) {
				if (len === 0 || len === 2) {
					sPagination = "/Service_Lookups/find/page?orderBy=Ascending&pno=" + pageNo + "&psize=" + that.pageSize + "&sortParam=bpId";
				} else if (len === 1) {
					var sQueryFilter = selectedItems[0];
					if (sQueryFilter === "Customer") {
						sPagination = "/Service_Lookups/find/findByRole?pno=" + pageNo + "&psize=" + that.pageSize + "&role=Customer";

					} else if (sQueryFilter === "Vendor") {
						sPagination = "/Service_Lookups/find/findByRole?pno=" + pageNo + "&psize=" + that.pageSize + "&role=Vendor";
					}
				}

			} else {
				if (len === 0 || len === 2) {
					if (sSelectedkeySearch === "Business Partner ID") {
						sPagination = "/Service_Lookups/find/findByBusinessId?bpRole=&bpId=" + sQuery + "&pno=" + pageNo + "&psize=" + that.pageSize +
							"";
					} else if (sSelectedkeySearch === "First Name") {
						sPagination = "/Service_Lookups/find/findByFirstName?bpRole=&firstName=" + sQuery + "&pno=" + pageNo + "&psize=" + that.pageSize +
							"";
					} else if (sSelectedkeySearch === "Last Name") {
						sPagination = "/Service_Lookups/find/findByLastName?bpRole=&lastName=" + sQuery + "&pno=" + pageNo + "&psize=" + that.pageSize +
							"";
					} else {
						sPagination = "/Service_Lookups/find/findByRoleId?bpRole=&pno=" + pageNo + "&psize=" + that.pageSize + "&roleId=" + sQuery;
					}
				} else if (len === 1) {
					sQueryFilter = selectedItems[0];
					if (sQueryFilter === "Customer") {
						if (sSelectedkeySearch === "Business Partner ID") {
							sPagination = "/Service_Lookups/find/findByBusinessId?bpRole=Customer&bpId=" + sQuery + "&pno=" + pageNo + "&psize=" + that.pageSize +
								"";
						} else if (sSelectedkeySearch === "First Name") {
							sPagination = "/Service_Lookups/find/findByFirstName?bpRole=Customer&firstName=" + sQuery + "&pno=" + pageNo + "&psize=" + that
								.pageSize + "";
						} else if (sSelectedkeySearch === "Last Name") {
							sPagination = "/Service_Lookups/find/findByLastName?bpRole=Customer&lastName=" + sQuery + "&pno=" + pageNo + "&psize=" + that.pageSize +
								"";
						} else {
							sPagination = "/Service_Lookups/find/findByRoleId?bpRole=Customer&pno=" + pageNo + "&psize=" + that.pageSize + "&roleId=" +
								sQuery;
						}

					} else if (sQueryFilter === "Vendor") {
						if (sSelectedkeySearch === "Business Partner ID") {
							sPagination = "/Service_Lookups/find/findByBusinessId?bpRole=Vendor&bpId=" + sQuery + "&pno=" + pageNo + "&psize=" + that.pageSize +
								"";
						} else if (sSelectedkeySearch === "First Name") {
							sPagination = "/Service_Lookups/find/findByFirstName?bpRole=Vendor&firstName=" + sQuery + "&pno=" + pageNo + "&psize=" + that.pageSize +
								"";
						} else if (sSelectedkeySearch === "Last Name") {
							sPagination = "/Service_Lookups/find/findByLastName?bpRole=Vendor&lastName=" + sQuery + "&pno=" + pageNo + "&psize=" + that.pageSize +
								"";
						} else {
							sPagination = "/Service_Lookups/find/findByRoleId?bpRole=Vendor&pno=" + pageNo + "&psize=" + that.pageSize + "&roleId=" +
								sQuery;
						}
					}
				}
			}
			this.searchPageUrl = sPagination;
			$.ajax({
				url: sPagination,
				dataType: "json",
				type: "GET",
				async: true,
				success: function (data, textStatus, jqXHR) {
					BusyIndicator.hide();
					// var len = data.length;
					console.log(data.listBusinessPartner);
					totalData = data.listBusinessPartner;
					that.searchTotalPage = data.totalPage;
					oJavaGlobalModel.setProperty("/listBusinessPartner", data.listBusinessPartner);
					console.log(that.searchTotalPage);
					oJavaGlobalModel.setProperty("/totalPages", that.searchTotalPage);

					oJavaGlobalModel.setProperty("/currentPage", pageNo + 1);
				},
				error: function (jqXHR, textStatus, errorThrown) {
					BusyIndicator.hide();
					MessageToast.show("Oh no, an error occurred");
				}
			});

			return totalData;
		},

		filterTotalPage: 0,
		filterClicks: 0,
		onFilter: function () {
			BusyIndicator.show(0);
			this.flag = 3;
			var that = this;
			var oJavaGlobalModel = this.getOwnerComponent().getModel("oJavaGlobalModel");
			// var selectedItems = oEvent.getParameter("selectedItems");
			// oJavaGlobalModel.setProperty("/selectedItems", selectedItems);
			var selectedItems = oJavaGlobalModel.getProperty("/filterQuery");
			var len;

			if (selectedItems === undefined) {
				len = 0;
			} else {
				len = selectedItems.length;
			}
			var bpIdDefault = "BP ID";
			var orderDefault = "Ascending";
			var totalData;
			var sPagination;
			var pageNo = 0;
			this.getView().getModel("oSortModel").setProperty("/sSelectedKeySort", bpIdDefault);
			this.getView().getModel("oOrderModel").setProperty("/sSelectedKeyOrder", orderDefault);
			if (len === 0 || len === 2) {
				sPagination = "/Service_Lookups/find/page?orderBy=Ascending&pno=" + pageNo + "&psize=" + that.pageSize + "&sortParam=bpId";

			} else if (len === 1) {
				var sQuery = selectedItems[0];
				if (sQuery === "Customer") {
					sPagination = "/Service_Lookups/find/findByRole?pno=" + pageNo + "&psize=" + that.pageSize + "&role=Customer";

				} else if (sQuery === "Vendor") {
					sPagination = "/Service_Lookups/find/findByRole?pno=" + pageNo + "&psize=" + that.pageSize + "&role=Vendor";
				}
			}

			$.ajax({
				url: sPagination,
				dataType: "json",
				type: "GET",
				async: true,
				success: function (data, textStatus, jqXHR) {
					BusyIndicator.hide();
					// var len = data.length;
					console.log(data.listBusinessPartner);
					totalData = data.listBusinessPartner;
					that.filterTotalPage = data.totalPage;
					oJavaGlobalModel.setProperty("/listBusinessPartner", data.listBusinessPartner);
					console.log(that.filterTotalPage);
					oJavaGlobalModel.setProperty("/totalPages", that.filterTotalPage);

					that.byId("previous").setEnabled(false);

					if (that.filterTotalPage === 1) {
						that.byId("next").setEnabled(false);
						that.byId("previous").setEnabled(false);
					} else {
						that.byId("next").setEnabled(true);
					}

					oJavaGlobalModel.setProperty("/currentPage", pageNo + 1);
				},
				error: function (jqXHR, textStatus, errorThrown) {
					BusyIndicator.hide();
					MessageToast.show("Oh no, an error occurred");
				}
			});
			that.filterClicks = 0;
			return totalData;
		},
		onFilterPagination: function () {
			BusyIndicator.show(0);
			var that = this;
			var oJavaGlobalModel = this.getOwnerComponent().getModel("oJavaGlobalModel");
			var selectedItems = oJavaGlobalModel.getProperty("/filterQuery");
			var len;

			if (selectedItems === undefined) {
				len = 0;
			} else {
				len = selectedItems.length;
			}

			var totalData;
			var sPagination;
			var pageNo = that.filterClicks;
			if (len === 0 || len === 2) {
				sPagination = "/Service_Lookups/find/page?orderBy=Ascending&pno=" + pageNo + "&psize=" + that.pageSize + "&sortParam=bpId";
			} else if (len === 1) {
				var sQuery = selectedItems[0];
				if (sQuery === "Customer") {
					sPagination = "/Service_Lookups/find/findByRole?pno=" + pageNo + "&psize=" + that.pageSize + "&role=Customer";

				} else if (sQuery === "Vendor") {
					sPagination = "/Service_Lookups/find/findByRole?pno=" + pageNo + "&psize=" + that.pageSize + "&role=Vendor";
				}
			}
			$.ajax({
				url: sPagination,
				dataType: "json",
				type: "GET",
				async: true,
				success: function (data, textStatus, jqXHR) {
					BusyIndicator.hide();
					// var len = data.length;
					console.log(data.listBusinessPartner);
					totalData = data.listBusinessPartner;
					that.filterTotalPage = data.totalPage;
					oJavaGlobalModel.setProperty("/listBusinessPartner", data.listBusinessPartner);
					console.log(that.filterTotalPage);
					oJavaGlobalModel.setProperty("/totalPages", that.filterTotalPage);

					oJavaGlobalModel.setProperty("/currentPage", pageNo + 1);
				},
				error: function (jqXHR, textStatus, errorThrown) {
					BusyIndicator.hide();
					MessageToast.show("Oh no, an error occurred");
				}
			});

			return totalData;
		},
		fnGotoPage: function () {
			var model = this.getOwnerComponent().getModel("oEditGlobalModel");
			var pageNo = model.getProperty("/gotoPage");
			return pageNo;
		},

		onGoto: function () {
			this.flag = 4;
			var oJavaGlobalModel = this.getOwnerComponent().getModel("oJavaGlobalModel");
			var sTotal = oJavaGlobalModel.getProperty("/totalPages");
			var gotoValid = this.getOwnerComponent().getModel("oEditGlobalModel").getProperty("/gotoPage");

			if (gotoValid <= sTotal) {

				var that = this;
				var goFlag = that.segFlag;

				var sSearchModel = this.getView().getModel("oSearchModel");
				var sModel = this.getView().getModel("oOrderModel");
				var sSelectedkeyOrder = sModel.getProperty("/sSelectedKeyOrder");
				var sDisplaySortModel = this.getView().getModel("oSortModel");
				var sSelectedkeySort = sDisplaySortModel.getProperty("/sSelectedKeySort");
				var sSelectedkeySearch = sSearchModel.getProperty("/sSelectedKeySearch");
				// console.log(sSelectedkeyOrder);
				var selectedItems = oJavaGlobalModel.getProperty("/filterQuery");

				if (selectedItems === undefined) {
					var len = 0;
				} else {
					len = selectedItems.length;
				}
				var sQuery = sSearchModel.getProperty("/searchQuery");

				var totalData;
				var sPagination;

				var pageNo = that.fnGotoPage() - 1;
				if (pageNo === 0) {
					this.byId("previous").setEnabled(false);
				} else {
					this.byId("previous").setEnabled(true);
				}

				if (goFlag === 1) {
					if (len === 0 || len === 2) {
						sPagination = "/Service_Lookups/find/page?orderBy=Ascending&pno=" + pageNo + "&psize=" + that.pageSize + "&sortParam=bpId";

					} else if (len === 1) {
						var sItem = selectedItems[0];
						if (sItem === "Customer") {
							sPagination = "/Service_Lookups/find/findByRole?pno=" + pageNo + "&psize=" + that.pageSize + "&role=Customer";

						} else if (sItem === "Vendor") {
							sPagination = "/Service_Lookups/find/findByRole?pno=" + pageNo + "&psize=" + that.pageSize + "&role=Vendor";
						}
					}
				} else if (goFlag === 2) {
					if (sQuery === "" || sQuery === undefined) {
						if (len === 0 || len === 2) {
							sPagination = "/Service_Lookups/find/page?orderBy=Ascending&pno=" + pageNo + "&psize=" + that.pageSize + "&sortParam=bpId";
						} else if (len === 1) {
							var sQueryFilter = selectedItems[0];
							if (sQueryFilter === "Customer") {
								sPagination = "/Service_Lookups/find/findByRole?pno=" + pageNo + "&psize=" + that.pageSize + "&role=Customer";

							} else if (sQueryFilter === "Vendor") {
								sPagination = "/Service_Lookups/find/findByRole?pno=" + pageNo + "&psize=" + that.pageSize + "&role=Vendor";
							}
						}

					} else {
						if (len === 0 || len === 2) {
							if (sSelectedkeySearch === "Business Partner ID") {
								sPagination = "/Service_Lookups/find/findByBusinessId?bpRole=&bpId=" + sQuery + "&pno=" + pageNo + "&psize=" + that.pageSize +
									"";
							} else if (sSelectedkeySearch === "First Name") {
								sPagination = "/Service_Lookups/find/findByFirstName?bpRole=&firstName=" + sQuery + "&pno=" + pageNo + "&psize=" + that.pageSize +
									"";
							} else if (sSelectedkeySearch === "Last Name") {
								sPagination = "/Service_Lookups/find/findByLastName?bpRole=&lastName=" + sQuery + "&pno=" + pageNo + "&psize=" + that.pageSize +
									"";
							} else {
								sPagination = "/Service_Lookups/find/findByRoleId?bpRole=&pno=" + pageNo + "&psize=" + that.pageSize + "&roleId=" + sQuery;
							}
						} else if (len === 1) {
							sQueryFilter = selectedItems[0];
							if (sQueryFilter === "Customer") {
								if (sSelectedkeySearch === "Business Partner ID") {
									sPagination = "/Service_Lookups/find/findByBusinessId?bpRole=Customer&bpId=" + sQuery + "&pno=" + pageNo + "&psize=" + that.pageSize +
										"";
								} else if (sSelectedkeySearch === "First Name") {
									sPagination = "/Service_Lookups/find/findByFirstName?bpRole=Customer&firstName=" + sQuery + "&pno=" + pageNo + "&psize=" +
										that
										.pageSize + "";
								} else if (sSelectedkeySearch === "Last Name") {
									sPagination = "/Service_Lookups/find/findByLastName?bpRole=Customer&lastName=" + sQuery + "&pno=" + pageNo + "&psize=" + that
										.pageSize +
										"";
								} else {
									sPagination = "/Service_Lookups/find/findByRoleId?bpRole=Customer&pno=" + pageNo + "&psize=" + that.pageSize + "&roleId=" +
										sQuery;
								}

							} else if (sQueryFilter === "Vendor") {
								if (sSelectedkeySearch === "Business Partner ID") {
									sPagination = "/Service_Lookups/find/findByBusinessId?bpRole=Vendor&bpId=" + sQuery + "&pno=" + pageNo + "&psize=" + that.pageSize +
										"";
								} else if (sSelectedkeySearch === "First Name") {
									sPagination = "/Service_Lookups/find/findByFirstName?bpRole=Vendor&firstName=" + sQuery + "&pno=" + pageNo + "&psize=" + that
										.pageSize +
										"";
								} else if (sSelectedkeySearch === "Last Name") {
									sPagination = "/Service_Lookups/find/findByLastName?bpRole=Vendor&lastName=" + sQuery + "&pno=" + pageNo + "&psize=" + that.pageSize +
										"";
								} else {
									sPagination = "/Service_Lookups/find/findByRoleId?bpRole=Vendor&pno=" + pageNo + "&psize=" + that.pageSize + "&roleId=" +
										sQuery;
								}
							}
						}
					}
				} else {
					if (sSelectedkeySort === "BP ID") {
						if (sSelectedkeyOrder === "Ascending") {
							sPagination = "/Service_Lookups/find/page?orderBy=" + sSelectedkeyOrder + "&pno=" + pageNo + "&psize=" + that.pageSize +
								"&sortParam=bpId";
						} else {
							sPagination = "/Service_Lookups/find/page?orderBy=" + sSelectedkeyOrder + "&pno=" + pageNo +
								"&psize=" + that.pageSize + "&sortParam=bpId";
						}
					} else if (sSelectedkeySort === "First Name") {
						if (sSelectedkeyOrder === "Ascending") {
							sPagination = "/Service_Lookups/find/page?orderBy=" + sSelectedkeyOrder + "&pno=" + pageNo +
								"&psize=" + that.pageSize + "&sortParam=firstName";
						} else {

							sPagination = "/Service_Lookups/find/page?orderBy=" + sSelectedkeyOrder + "&pno=" + pageNo +
								"&psize=" + that.pageSize + "&sortParam=firstName";
						}
					} else if (sSelectedkeySort === "Last Name") {
						if (sSelectedkeyOrder === "Ascending") {
							sPagination = "/Service_Lookups/find/page?orderBy=" + sSelectedkeyOrder + "&pno=" + pageNo +
								"&psize=" + that.pageSize + "&sortParam=lastName";
						} else {
							sPagination = "/Service_Lookups/find/page?orderBy=" + sSelectedkeyOrder + "&pno=" + pageNo +
								"&psize=" + that.pageSize + "&sortParam=lastName";
						}
					} else {
						if (sSelectedkeyOrder === "Ascending") {
							sPagination = "/Service_Lookups/find/page?orderBy=" + sSelectedkeyOrder + "&pno=" + pageNo +
								"&psize=" + that.pageSize + "&sortParam=roleId";
						} else {
							sPagination = "/Service_Lookups/find/page?orderBy=" + sSelectedkeyOrder + "&pno=" + pageNo +
								"&psize=" + that.pageSize + "&sortParam=roleId";
						}
					}
				}
				BusyIndicator.show(0);
				$.ajax({
					url: sPagination,
					dataType: "json",
					type: "GET",
					async: true,
					success: function (data, textStatus, jqXHR) {
						BusyIndicator.hide();
						console.log(data.listBusinessPartner);
						totalData = data.listBusinessPartner;
						that.gotoTotalPage = data.totalPage;
						oJavaGlobalModel.setProperty("/listBusinessPartner", data.listBusinessPartner);
						console.log(that.gotoTotalPage);
						oJavaGlobalModel.setProperty("/totalPages", that.gotoTotalPage);
						if (pageNo === (that.gotoTotalPage - 1)) {
							that.byId("next").setEnabled(false);
						}
						oJavaGlobalModel.setProperty("/currentPage", pageNo + 1);
					},
					error: function (error) {
						BusyIndicator.hide();
						MessageToast.show("Oh no, an error occurred");
						console.log(error);
					}
				});

				return totalData;

			} else {
				MessageToast.show("Please enter a valid page number");
			}

		},
		onGotoPagination: function (sGoto) {
			BusyIndicator.show(0);
			var that = this;
			var pageNo = sGoto - 1;
			var goFlag = that.segFlag;
			var oJavaGlobalModel = this.getOwnerComponent().getModel("oJavaGlobalModel");
			var oEditGlobalModel = this.getOwnerComponent().getModel("oEditGlobalModel");
			var sSearchModel = this.getView().getModel("oSearchModel");
			var sModel = this.getView().getModel("oOrderModel");
			var sSelectedkeyOrder = sModel.getProperty("/sSelectedKeyOrder");
			var sDisplaySortModel = this.getView().getModel("oSortModel");
			var sSelectedkeySort = sDisplaySortModel.getProperty("/sSelectedKeySort");
			var sSelectedkeySearch = sSearchModel.getProperty("/sSelectedKeySearch");
			// console.log(sSelectedkeyOrder);
			var selectedItems = oJavaGlobalModel.getProperty("/filterQuery");
			var len;

			if (selectedItems === undefined) {
				len = 0;
			} else {
				len = selectedItems.length;
			}
			var sQuery = sSearchModel.getProperty("/searchQuery");

			var totalData;
			var sPagination;
			if (goFlag === 1) {
				if (len === 0 || len === 2) {
					sPagination = "/Service_Lookups/find/page?orderBy=Ascending&pno=" + pageNo + "&psize=" + that.pageSize + "&sortParam=bpId";

				} else if (len === 1) {
					var sItem = selectedItems[0];
					if (sItem === "Customer") {
						sPagination = "/Service_Lookups/find/findByRole?pno=" + pageNo + "&psize=" + that.pageSize + "&role=Customer";

					} else if (sItem === "Vendor") {
						sPagination = "/Service_Lookups/find/findByRole?pno=" + pageNo + "&psize=" + that.pageSize + "&role=Vendor";
					}
				}
			} else if (goFlag === 2) {
				if (sQuery === "" || sQuery === undefined) {
					if (len === 0 || len === 2) {
						sPagination = "/Service_Lookups/find/page?orderBy=Ascending&pno=" + pageNo + "&psize=" + that.pageSize + "&sortParam=bpId";
					} else if (len === 1) {
						var sQueryFilter = selectedItems[0];
						if (sQueryFilter === "Customer") {
							sPagination = "/Service_Lookups/find/findByRole?pno=" + pageNo + "&psize=" + that.pageSize + "&role=Customer";

						} else if (sQueryFilter === "Vendor") {
							sPagination = "/Service_Lookups/find/findByRole?pno=" + pageNo + "&psize=" + that.pageSize + "&role=Vendor";
						}
					}

				} else {
					if (len === 0 || len === 2) {
						if (sSelectedkeySearch === "Business Partner ID") {
							sPagination = "/Service_Lookups/find/findByBusinessId?bpRole=&bpId=" + sQuery + "&pno=" + pageNo + "&psize=" + that.pageSize +
								"";
						} else if (sSelectedkeySearch === "First Name") {
							sPagination = "/Service_Lookups/find/findByFirstName?bpRole=&firstName=" + sQuery + "&pno=" + pageNo + "&psize=" + that.pageSize +
								"";
						} else if (sSelectedkeySearch === "Last Name") {
							sPagination = "/Service_Lookups/find/findByLastName?bpRole=&lastName=" + sQuery + "&pno=" + pageNo + "&psize=" + that.pageSize +
								"";
						} else {
							sPagination = "/Service_Lookups/find/findByRoleId?bpRole=&pno=" + pageNo + "&psize=" + that.pageSize + "&roleId=" + sQuery;
						}
					} else if (len === 1) {
						sQueryFilter = selectedItems[0];
						if (sQueryFilter === "Customer") {
							if (sSelectedkeySearch === "Business Partner ID") {
								sPagination = "/Service_Lookups/find/findByBusinessId?bpRole=Customer&bpId=" + sQuery + "&pno=" + pageNo + "&psize=" + that.pageSize +
									"";
							} else if (sSelectedkeySearch === "First Name") {
								sPagination = "/Service_Lookups/find/findByFirstName?bpRole=Customer&firstName=" + sQuery + "&pno=" + pageNo + "&psize=" +
									that
									.pageSize + "";
							} else if (sSelectedkeySearch === "Last Name") {
								sPagination = "/Service_Lookups/find/findByLastName?bpRole=Customer&lastName=" + sQuery + "&pno=" + pageNo + "&psize=" + that.pageSize +
									"";
							} else {
								sPagination = "/Service_Lookups/find/findByRoleId?bpRole=Customer&pno=" + pageNo + "&psize=" + that.pageSize + "&roleId=" +
									sQuery;
							}

						} else if (sQueryFilter === "Vendor") {
							if (sSelectedkeySearch === "Business Partner ID") {
								sPagination = "/Service_Lookups/find/findByBusinessId?bpRole=Vendor&bpId=" + sQuery + "&pno=" + pageNo + "&psize=" + that.pageSize +
									"";
							} else if (sSelectedkeySearch === "First Name") {
								sPagination = "/Service_Lookups/find/findByFirstName?bpRole=Vendor&firstName=" + sQuery + "&pno=" + pageNo + "&psize=" + that.pageSize +
									"";
							} else if (sSelectedkeySearch === "Last Name") {
								sPagination = "/Service_Lookups/find/findByLastName?bpRole=Vendor&lastName=" + sQuery + "&pno=" + pageNo + "&psize=" + that.pageSize +
									"";
							} else {
								sPagination = "/Service_Lookups/find/findByRoleId?bpRole=Vendor&pno=" + pageNo + "&psize=" + that.pageSize + "&roleId=" +
									sQuery;
							}
						}
					}
				}
			} else {
				if (sSelectedkeySort === "BP ID") {
					if (sSelectedkeyOrder === "Ascending") {
						sPagination = "/Service_Lookups/find/page?orderBy=" + sSelectedkeyOrder + "&pno=" + pageNo + "&psize=" + that.pageSize +
							"&sortParam=bpId";
					} else {
						sPagination = "/Service_Lookups/find/page?orderBy=" + sSelectedkeyOrder + "&pno=" + pageNo +
							"&psize=" + that.pageSize + "&sortParam=bpId";
					}
				} else if (sSelectedkeySort === "First Name") {
					if (sSelectedkeyOrder === "Ascending") {
						sPagination = "/Service_Lookups/find/page?orderBy=" + sSelectedkeyOrder + "&pno=" + pageNo +
							"&psize=" + that.pageSize + "&sortParam=firstName";
					} else {

						sPagination = "/Service_Lookups/find/page?orderBy=" + sSelectedkeyOrder + "&pno=" + pageNo +
							"&psize=" + that.pageSize + "&sortParam=firstName";
					}
				} else if (sSelectedkeySort === "Last Name") {
					if (sSelectedkeyOrder === "Ascending") {
						sPagination = "/Service_Lookups/find/page?orderBy=" + sSelectedkeyOrder + "&pno=" + pageNo +
							"&psize=" + that.pageSize + "&sortParam=lastName";
					} else {
						sPagination = "/Service_Lookups/find/page?orderBy=" + sSelectedkeyOrder + "&pno=" + pageNo +
							"&psize=" + that.pageSize + "&sortParam=lastName";
					}
				} else {
					if (sSelectedkeyOrder === "Ascending") {
						sPagination = "/Service_Lookups/find/page?orderBy=" + sSelectedkeyOrder + "&pno=" + pageNo +
							"&psize=" + that.pageSize + "&sortParam=roleId";
					} else {
						sPagination = "/Service_Lookups/find/page?orderBy=" + sSelectedkeyOrder + "&pno=" + pageNo +
							"&psize=" + that.pageSize + "&sortParam=roleId";
					}
				}
			}

			$.ajax({
				url: sPagination,
				dataType: "json",
				type: "GET",
				async: true,
				success: function (data, textStatus, jqXHR) {
					BusyIndicator.hide();
					// var len = data.length;
					console.log(data.listBusinessPartner);
					totalData = data.listBusinessPartner;
					that.gotoTotalPage = data.totalPage;
					oJavaGlobalModel.setProperty("/listBusinessPartner", data.listBusinessPartner);
					console.log(that.gotoTotalPage);
					oJavaGlobalModel.setProperty("/totalPages", that.gotoTotalPage);

					oJavaGlobalModel.setProperty("/currentPage", pageNo + 1);
					oEditGlobalModel.setProperty("/gotoPage", pageNo + 1);
				},
				error: function (error) {
					BusyIndicator.hide();
					MessageToast.show("Oh no, an error occurred");
					console.log(error);
				}
			});

			return totalData;
		},

		onNext: function () {
			var that = this;
			// var oJavaGlobalModel = this.getOwnerComponent().getModel("oJavaGlobalModel");
			var oSearchModel = this.getView().getModel("oSearchModel");
			var bFlag = that.flag;

			if (bFlag === 2) {
				var sQuery = oSearchModel.getProperty("/searchQuery");
				that.searchClicks++;
				that.onSearchPagination(sQuery);

				if (that.searchClicks > 0) {
					this.byId("previous").setEnabled(true);
				}

				if (that.searchClicks === (that.searchTotalPage - 1)) {
					this.byId("next").setEnabled(false);
				}
			}

			if (bFlag === 1) {
				that.sortClicks++;
				that.onSort();
				if (that.sortClicks > 0) {
					this.byId("previous").setEnabled(true);
				}

				if (that.sortClicks === (that.sortTotalPage - 1)) {
					this.byId("next").setEnabled(false);
				}
			}

			if (bFlag === 0) {
				that.clicks++;
				that.fnPagination();
				if (that.clicks > 0) {
					this.byId("previous").setEnabled(true);
				}

				if (that.clicks === (that.totalPage - 1)) {
					this.byId("next").setEnabled(false);
				}
			}

			if (bFlag === 3) {
				that.filterClicks++;
				that.onFilterPagination();
				if (that.filterClicks > 0) {
					this.byId("previous").setEnabled(true);
				}

				if (that.filterClicks === (that.filterTotalPage - 1)) {
					this.byId("next").setEnabled(false);
				}
			}

			if (bFlag === 4) {
				var pg = that.fnGotoPage();
				pg++;
				that.onGotoPagination(pg);
				if (pg > 0) {
					this.byId("previous").setEnabled(true);
				}

				if (pg >= (that.gotoTotalPage)) {
					this.byId("next").setEnabled(false);
				}

			}

			// if (this.clicks >= 0) {
			// 	this.byId("previous").setEnabled(true);
			// }
			// if (this.totalPage - 1 === this.clicks) {
			// 	this.byId("next").setEnabled(false);
			// }

			// var count = this.clicks;
			// if (sPagination === "" && this.searchPageUrl === "") {
			// 	this.fnPagination();

			// } else if (sPagination !== "" && this.searchPageUrl === "") {
			// 	this.onSort();

			// } else if (this.searchPageUrl !== "") {
			// 	this.onSearchPagination(sQuery);

			// }
			// var count = this.clicks;
			// oJavaGlobalModel.setProperty("/currentPage", count + 1);
			// console.log(this.clicks);

			// if (this.totalPage == 1) {
			// 	this.getView().byId("next").setEnabled(false);

			// }
		},
		onPrevious: function (oEvent) {

			var that = this;
			var oSearchModel = this.getView().getModel("oSearchModel");
			var bFlag = that.flag;

			if (bFlag === 2) {
				var sQuery = oSearchModel.getProperty("/searchQuery");
				that.searchClicks--;
				that.onSearchPagination(sQuery);

				if (that.searchClicks === 0) {
					this.byId("previous").setEnabled(false);

				}
				if (that.searchClicks < (that.searchTotalPage - 1)) {
					this.byId("next").setEnabled(true);
				}
			}

			if (bFlag === 1) {
				that.sortClicks--;
				that.onSort();
				if (that.sortClicks === 0) {
					this.byId("previous").setEnabled(false);
				}
				if (that.sortClicks < (that.sortTotalPage - 1)) {
					this.byId("next").setEnabled(true);
				}
			}

			if (bFlag === 0) {
				that.clicks--;
				that.fnPagination();
				if (that.clicks === 0) {
					this.byId("previous").setEnabled(false);
				}
				if (that.clicks < (that.totalPage - 1)) {
					this.byId("next").setEnabled(true);
				}
			}

			if (bFlag === 3) {
				that.filterClicks--;
				that.onFilterPagination();
				if (that.filterClicks === 0) {
					this.byId("previous").setEnabled(false);
				}

				if (that.filterClicks < (that.filterTotalPage - 1)) {
					this.byId("next").setEnabled(true);
				}
			}

			if (bFlag === 4) {
				var pg = that.fnGotoPage();
				pg--;
				that.onGotoPagination(pg);
				if (pg > 1) {
					this.byId("previous").setEnabled(true);
				} else {
					this.byId("previous").setEnabled(false);
				}

				if (pg < (that.gotoTotalPage)) {
					this.byId("next").setEnabled(true);
				} else {
					this.byId("next").setEnabled(false);
				}

			}

			// Ashish

			// var oJavaGlobalModel = this.getOwnerComponent().getModel("oJavaGlobalModel");
			// var sQuery = oJavaGlobalModel.getProperty("/searchParam");
			// this.clicks--;
			// // if (this.totalPage === 1) {
			// // 	// oJavaGlobalModel.setProperty("/currentPage", count );
			// // 	// this.byId("next").setEnabled(false);
			// // 	this.byId("previous").setEnabled(false);

			// // }
			// if (this.clicks <= 0) {
			// 	this.byId("previous").setEnabled(false);

			// }
			// if (this.totalPage !== this.clicks) {
			// 	this.byId("next").setEnabled(true);
			// }
			// var count = this.clicks;
			// oJavaGlobalModel.setProperty("/currentPage", count);
			// if (sPagination === "" && this.searchPageUrl === "") {
			// 	this.fnPagination();
			// } else if (sPagination !== "" && this.searchPageUrl === "") {
			// 	this.onSort();
			// } else if (this.searchPageUrl !== "") {
			// 	this.onSearchPagination(sQuery);
			// 	// if (this.totalPage === 1) {
			// 	// 	this.byId("next").setEnabled(false);
			// 	// 	this.byId("previous").setEnabled(false);
			// 	// }
			// }
			// console.log(this.clicks);
			// // this.fnPagination();

		},
		onCreateBusinessPartner: function (oEvent) {

			var that = this;
			var oDataModel = this.getOwnerComponent().getModel("oDataModel");
			var addr = oDataModel.getProperty("/address");
			var pay = oDataModel.getProperty("/payment");

			var aAddr = [];
			for (var i = 0; i < addr.length; i++) {
				if (!(addr[i].street === "" && addr[i].street2 === "" && addr[i].street4 === "" && addr[i].postalCode === "" &&
						addr[i].city === "" && addr[i].country === "" && addr[i].email === "" && addr[i].telephone === "")) {
					aAddr.push(addr[i]);
				}
			}

			oDataModel.setProperty("/address", aAddr);

			var aPay = [];
			for (var j = 0; j < pay.length; j++) {
				if (!(pay[j].id === "" && pay[j].pCity === "" && pay[j].bankKey === "" && pay[j].bankAcct === "" && pay[j].controlKey === "" &&
						pay[j].iban === "" && pay[j].refDoc === "")) {
					aPay.push(pay[j]);
				}
			}
			oDataModel.setProperty("/payment", aPay);

			var postData = oDataModel.getData();
			var sPostUrl = "/Service_Lookups/bpc/saveBupa";
			// Use Token
			var basicData = this.getOwnerComponent().getModel("oDataModel").getProperty("/basicDetails");
			var nameRegex = /^[a-zA-Z]{1,35}$/;
			var aError = [];
			var basic = "";
			var flag = 1;
			var flag1 = this.fnCheckCommunications();
			var flag2 = this.fnCheckIdentifications();
			var flag3 = this.fnCheckAddress();
			var flag4 = this.fnCheckPayment();
			if (flag3 === 2) {
				MessageToast.show(this.addrEmpty.join(" "));
			}
			if (flag4 === 2) {
				MessageToast.show(this.addrEmpty1.join(" "));
			}
			if (basicData.fname === undefined && basicData.lname === undefined && basicData.sTerm1 === undefined && basicData.sTerm2 ===
				undefined && basicData.sLanguage === undefined && basicData.sRole === undefined) {
				basic = "Basic Data is not Filled";
				MessageToast.show(basic);
				flag = 2;
			} else {

				if (basicData.fname === undefined || basicData.fname === "") {
					aError.push("First Name is not filled\r\n");
					flag = 0;
					this.getView().byId("fnId").setValueState("Error");
				} else if (!nameRegex.test(basicData.fname)) {
					aError.push("First Name must not include Special character or Number\r\n");
					flag = 0;
					this.getView().byId("fnId").setValueState("Error");
				} else {
					this.getView().byId("fnId").setValueState("None");
				}
				if (basicData.lname === undefined || basicData.lname === "") {
					aError.push("Last Name is not filled\r\n");
					flag = 0;
					this.getView().byId("lnId").setValueState("Error");
				} else if (!nameRegex.test(basicData.lname)) {
					aError.push("Last Name must not include Special character or Number\r\n");
					flag = 0;
					this.getView().byId("lnId").setValueState("Error");
				} else {
					this.getView().byId("lnId").setValueState("None");
				}
				if (basicData.sTerm1 === undefined || basicData.sTerm1 === "") {
					aError.push("Search Term 1 is not filled\r\n");
					flag = 0;
					this.getView().byId("st1Id").setValueState("Error");
				} else {
					this.getView().byId("st1Id").setValueState("None");
				}
				if (basicData.sTerm2 === undefined || basicData.sTerm2 === "") {
					aError.push("Search Term 2 is not filled\r\n");
					flag = 0;
					this.getView().byId("st2Id").setValueState("Error");
				} else {
					this.getView().byId("st2Id").setValueState("None");
				}
				if (basicData.sLanguage === undefined || basicData.sLanguage === "") {
					aError.push("Language is not filled\r\n");
					flag = 0;
					this.getView().byId("langId").setValueState("Error");
				} else {
					this.getView().byId("langId").setValueState("None");
				}
				if (basicData.sRole === undefined || basicData.sRole === "") {
					aError.push("BP Role is not filled\r\n");
					flag = 0;
					this.getView().byId("brId").setValueState("Error");
				} else {
					this.getView().byId("brId").setValueState("None");
				}
				if (flag === 0) {
					MessageToast.show(aError.join(" "));
					//	oDataModel.setProperty("/basicDetails/error", "Error");
				}
			}
			// BusyIndicator.show(0);
			if (flag === 1 && flag1 === 1 && flag2 === 1 && flag3 === 1 && flag4 === 1) {
				$.ajax({
					type: "POST",
					url: sPostUrl,
					data: JSON.stringify(postData),
					contentType: "application/json",
					dataType: "json",
					async: false,
					headers: {
						"X-CSRF-Token": this.myToken
					},
					success: function (data, status, response) {
						// BusyIndicator.hide();
						console.log(data);
						console.log(status);
						console.log(response);
						// MessageToast.show("Thank you Partner!! Business Partner with BP number " + data + " has been successfully created");
						oDataModel.setProperty("/BPnum", data);
						if (data.status === true) {
							if (!that._oDialog) {
								that._oDialog = sap.ui.xmlfragment("idAddItemFrag", "inc.inkt.od.ZMasterData.fragment.successDialog", that); // Instantiating the Fragment
							}
							that.getView().addDependent(that._oDialog);
							that._oDialog.open();
							that.onReset();
						} else {
							if (!that._oDialog) {
								that._oDialog = sap.ui.xmlfragment("idAddItemFrag", "inc.inkt.od.ZMasterData.fragment.errorDialog", that); // Instantiating the Fragment
							}
							that.getView().addDependent(that._oDialog);
							that._oDialog.open();
						}
					},
					error: function (error) {
						// BusyIndicator.hide();
						console.log(error);
						MessageToast.show("Connection Failed");
					}
				});
			}
			// this.onReset();
			var id = oDataModel.getProperty("/BPnum/role_id");
			// console.log(id)
			if (id >= 10000 && id <= 20000) {
				Fragment.byId("idAddItemFrag", "customer").setVisible(true);
			} else if (id >= 20001 && id <= 30000) {
				Fragment.byId("idAddItemFrag", "vendor").setVisible(true);
			}
			// console.log(id);

		},
		row: [],
		addrEmpty: [],
		fnCheckAddress: function () {
			console.log(this.row);

			var tableModel = this.getOwnerComponent().getModel("oDataModel");
			var tableData = tableModel.getProperty("/address");
			var lenAddress = tableData.length;
			console.log(lenAddress);
			tableModel.setProperty("/tableLength", lenAddress);
			while (this.row.length > 0) {
				this.row.pop();
			}
			while (this.addrEmpty.length > 0) {
				this.addrEmpty.pop();
			}
			console.log(this.row);
			var flag = 1;
			var e = "Error";
			var n = "None";
			var mailregex = /^([a-zA-Z0-9\.-_]+)@([a-zA-Z0-9-]+)\.([a-z]{2,15})(\.[a-z]{2,15})?$/;

			for (var i = 0; i < lenAddress; i++) {

				var cellStreetVal = tableData[i].street;
				var cellPostalVal = tableData[i].postalCode;
				var cellCityVal = tableData[i].city;
				var cellCountryVal = tableData[i].country;
				var cellEmailVal = tableData[i].email;
				var cellTelephoneVal = tableData[i].telephone;

				if (cellStreetVal === "" && cellPostalVal === "" && cellCityVal === "" && cellCountryVal ===
					"" && cellEmailVal === "" && cellTelephoneVal === undefined) {
					this.addrEmpty.push("Please fill the Required Field\r\n");
					flag = 2;
					break;
				} else {
					if (cellStreetVal === "" || cellStreetVal === undefined) {
						this.row.push(i + " Street is empty\r\n");

						tableModel.setProperty("/address/" + i + "/streetState", e);
						flag = 0;
					} else {
						tableModel.setProperty("/address/" + i + "/streetState", n);
					}
					if (cellPostalVal === "" || cellPostalVal === undefined) {
						this.row.push(i + " Postal Code is empty\r\n");
						tableModel.setProperty("/address/" + i + "/postalCodeState", e);
						flag = 0;
					} else {
						tableModel.setProperty("/address/" + i + "/postalCodeState", n);
					}
					if (cellCityVal === "" || cellCityVal === undefined) {
						this.row.push(i + " City is empty\r\n");
						tableModel.setProperty("/address/" + i + "/cityState", e);
						flag = 0;
					} else {
						tableModel.setProperty("/address/" + i + "/cityState", n);
					}
					if (cellCountryVal === "" || cellCountryVal === undefined) {
						this.row.push(i + " Country is empty\r\n");
						tableModel.setProperty("/address/" + i + "/countryState", e);
						flag = 0;
					} else {
						tableModel.setProperty("/address/" + i + "/countryState", n);
					}
					if (cellEmailVal === "" || cellEmailVal === undefined) {
						this.row.push(i + " Email is empty\r\n");
						tableModel.setProperty("/address/" + i + "/emailState", e);
						flag = 0;
					} else if (!mailregex.test(cellEmailVal)) {
						this.row.push(i + " Email is not in the right format\r\n");
						tableModel.setProperty("/address/" + i + "/emailState", e);
						flag = 0;
					} else {
						tableModel.setProperty("/address/" + i + "/emailState", n);
					}
					if (cellTelephoneVal === "" || cellTelephoneVal === undefined) {
						this.row.push(i + " Telephone is empty\r\n");
						tableModel.setProperty("/address/" + i + "/telephoneState", e);
						flag = 0;
					} else if (cellTelephoneVal.length > 10 && cellTelephoneVal.length < 0) {
						this.row.push(i + " Telephone number should be of 10 digit\r\n");
						tableModel.setProperty("/address/" + i + "/telephoneState", e);
						flag = 0;
					} else {
						tableModel.setProperty("/address/" + i + "/telephoneState", n);
					}
				}
			}
			if (flag === 0) {
				MessageToast.show(this.row.join(" "));
			}
			return flag;

		},
		row1: [],
		addrEmpty1: [],
		fnCheckPayment: function () {

			console.log(this.row1);

			var tableModel = this.getOwnerComponent().getModel("oDataModel");
			var tableData = tableModel.getProperty("/payment");
			var lenPayment = tableData.length;
			console.log(lenPayment);
			tableModel.setProperty("/paymentLength", lenPayment);
			while (this.row1.length > 0) {
				this.row1.pop();
			}
			while (this.addrEmpty1.length > 0) {
				this.addrEmpty1.pop();
			}
			console.log(this.row1);
			var flag = 1;
			var e = "Error";
			var n = "None";

			for (var i = 0; i < lenPayment; i++) {

				var cellIdVal = tableData[i].id;
				var cellPaymentCityVal = tableData[i].pCity;
				var cellBankKeyVal = tableData[i].bankKey;
				var cellBankAcctVal = tableData[i].bankAcct;
				var cellRefDocVal = tableData[i].refDoc;

				if (cellIdVal === "" && cellPaymentCityVal === "" && cellBankKeyVal === "" && cellBankAcctVal ===
					undefined) {

					this.addrEmpty1.push("Please fill the Required Field\r\n");
					flag = 2;
					break;
				} else {
					if (cellIdVal === "" || cellIdVal === undefined) {
						this.row1.push(i + " ID is empty\r\n");

						tableModel.setProperty("/payment/" + i + "/idState", e);
						flag = 0;
					} else {
						tableModel.setProperty("/payment/" + i + "/idState", n);
					}
					if (cellPaymentCityVal === "" || cellPaymentCityVal === undefined) {
						this.row1.push(i + " City is empty\r\n");
						tableModel.setProperty("/payment/" + i + "/pCityState", e);
						flag = 0;
					} else {
						tableModel.setProperty("/payment/" + i + "/pCityState", n);
					}
					if (cellBankKeyVal === "" || cellBankKeyVal === undefined) {
						this.row1.push(i + " Bank Key is empty\r\n");
						tableModel.setProperty("/payment/" + i + "/bankKeyState", e);
						flag = 0;
					} else {
						tableModel.setProperty("/payment/" + i + "/bankKeyState", n);
					}
					if (cellBankAcctVal === "" || cellBankAcctVal === undefined) {
						this.row1.push(i + " Bank Account is empty\r\n");
						tableModel.setProperty("/payment/" + i + "/bankAcctState", e);
						flag = 0;
					} else {
						tableModel.setProperty("/payment/" + i + "/bankAcctState", n);
					}
					if (cellRefDocVal === "" || cellRefDocVal === undefined) {
						this.row1.push(i + " Reference Document is empty\r\n");
						tableModel.setProperty("/payment/" + i + "/refDocState", e);
						flag = 0;
					} else {
						tableModel.setProperty("/payment/" + i + "/refDocState", n);
					}
				}

			}
			if (flag === 0) {
				MessageToast.show(this.row1.join(" "));
			}
			return flag;

		},
		fnCheckCommunications: function () {
			var aError = [];
			var flag = 1;
			var mailregex = /^([a-zA-Z0-9\.-_]+)@([a-zA-Z0-9-]+)\.([a-z]{2,15})(\.[a-z]{2,15})?$/;
			var mobileregex = /^[1-9]\d{9}$/;
			var commData = this.getOwnerComponent().getModel("oDataModel").getProperty("/communications");
			if (commData.comments === "" && commData.email === "" && commData.extAddress === "" && commData.fax === "" && commData.mobile ===
				"" && commData.standCommMethod === "" && commData.telephone === "") {
				flag = 1;
			} else {
				if (commData.mobile === undefined || commData.mobile === "") {
					aError.push("Mobile Number is not filled\r\n");

					flag = 0;
					this.getView().byId("mobId").setValueState("Error");
				} else if (!mobileregex.test(commData.mobile)) {
					aError.push("Mobile number is incorrect\r\n");
					this.getView().byId("mobId").setValueState("Error");
					flag = 0;
				} else {
					this.getView().byId("mobId").setValueState("None");
				}
				if (commData.standCommMethod === undefined || commData.standCommMethod === "") {
					aError.push("Communication method is not filled\r\n");

					flag = 0;
					this.getView().byId("cmId").setValueState("Error");
				} else {
					this.getView().byId("cmId").setValueState("None");
				}
				if (commData.extAddress === undefined || commData.extAddress === "") {
					aError.push("External address is not filled\r\n");

					flag = 0;
					this.getView().byId("extId").setValueState("Error");
				} else {
					this.getView().byId("extId").setValueState("None");
				}
				if (commData.email === undefined || commData.email === "") {
					aError.push("Email is not filled\r\n");

					flag = 0;
					this.getView().byId("mailId").setValueState("Error");
				} else if (!mailregex.test(commData.email)) {
					aError.push(" Email is not in the right format\r\n");
					this.getView().byId("mailId").setValueState("Error");
					flag = 0;
				} else {
					this.getView().byId("mailId").setValueState("None");
				}
			}

			if (flag === 0) {
				MessageToast.show(aError.join(" "));
			}
			return flag;
		},

		fnCheckIdentifications: function () {
			var aError = [];
			var flag = 1;
			var idenData = this.getOwnerComponent().getModel("oDataModel").getProperty("/identifications");

			if (idenData.birthPlace === "" && idenData.country === "" && idenData.countryOfOrigin === "" && idenData.employer === "" &&
				idenData.maritalStatus === "" && idenData.nationality === "" && idenData.occupation === "" && idenData.personnelNo === "" &&
				idenData.uname === "") {
				flag = 1;
			} else {
				if (idenData.occupation === undefined || idenData.occupation === "") {
					aError.push("Occupation is not chosen\r\n");
					flag = 0;
					this.getView().byId("occId").setValueState("Error");
				} else {
					this.getView().byId("occId").setValueState("None");
				}
				if (idenData.countryOfOrigin === undefined || idenData.countryOfOrigin === "") {
					aError.push("Country of Origin is not chosen\r\n");
					flag = 0;
					this.getView().byId("originId").setValueState("Error");
				} else {
					this.getView().byId("originId").setValueState("None");
				}
				if (idenData.nationality === undefined || idenData.nationality === "") {
					aError.push("Nationality is not chosen\r\n");
					flag = 0;
					this.getView().byId("natId").setValueState("Error");
				} else {
					this.getView().byId("natId").setValueState("None");
				}
				if (idenData.country === undefined || idenData.country === "") {
					aError.push("Citizenship is not chosen\r\n");
					flag = 0;
					this.getView().byId("citizenId").setValueState("Error");
				} else {
					this.getView().byId("citizenId").setValueState("None");
				}
			}
			if (flag === 0) {
				MessageToast.show(aError.join(" "));
			}
			return flag;
		},
		onPressOkay: function () {
			var that = this;
			that._oDialog.close();
			that._oDialog.destroy();
			that._oDialog = null;
		},
		onReset: function () {
			var oDataModel = this.getOwnerComponent().getModel("oDataModel");

			var oBasicData = {};
			// var oBPnum = {};
			var oAddress = [];
			var oPayment = [];
			var oCreateComm = this.createComm();
			var oIdentification = this.createIdent();

			oDataModel.setProperty("/basicDetails", oBasicData);
			oDataModel.setProperty("/address", oAddress);
			oDataModel.setProperty("/payment", oPayment);
			oDataModel.setProperty("/identifications", oIdentification);
			oDataModel.setProperty("/communications", oCreateComm);
			// oDataModel.setProperty("/BPnum", oBPnum);
			this.getView().byId("fnId").setValueState("None");
			this.getView().byId("lnId").setValueState("None");
			this.getView().byId("st1Id").setValueState("None");
			this.getView().byId("st2Id").setValueState("None");
			this.getView().byId("langId").setValueState("None");
			this.getView().byId("brId").setValueState("None");

			this.getView().byId("mobId").setValueState("None");
			this.getView().byId("cmId").setValueState("None");
			this.getView().byId("extId").setValueState("None");
			this.getView().byId("mailId").setValueState("None");
			this.getView().byId("occId").setValueState("None");
			this.getView().byId("originId").setValueState("None");
			this.getView().byId("natId").setValueState("None");
			this.getView().byId("citizenId").setValueState("None");

			console.log(oDataModel.getData());
		},
		showMore: function () {
			this.byId("showMore").setVisible(false);
			this.byId("showLess").setVisible(true);
			this.byId("SplitAppDemo").setVisible(true);
		},
		showLess: function () {
			this.byId("showMore").setVisible(true);
			this.byId("showLess").setVisible(false);
			this.byId("SplitAppDemo").setVisible(false);
		},

		onDeleteAddress: function (oEvent) {

			var rowPath = oEvent.getSource().getBindingContext("oDataModel").getPath();
			var path = rowPath + "";
			var index = path[path.length - 1];

			var tableModel = this.getOwnerComponent().getModel("oDataModel");
			var tableData = tableModel.getProperty("/address");
			tableData.splice(index, 1);
			tableModel.refresh();
			console.log(tableModel.getProperty("/address"));
		},
		onDeletePayment: function (oEvent) {
			var rowPath = oEvent.getSource().getBindingContext("oDataModel").getPath();
			var path = rowPath + "";
			var index = path[path.length - 1];

			// removing fromtable

			var tableModel = this.getOwnerComponent().getModel("oDataModel");
			var tableData = tableModel.getProperty("/payment");
			tableData.splice(index, 1);
			tableModel.refresh();
			console.log(tableModel.getProperty("/payment"));
		},
		onAddPress: function () {
			var model = this.getOwnerComponent().getModel("oDataModel");
			var flag = this.fnCheckAddress();
			if (flag === 1) {

				var currentRows = model.getProperty("/address");
				var newRows = currentRows.concat(this.createEntry());
				model.setProperty("/address", newRows);

			}
			// else {
			// 	MessageToast.show("New Row can't be Added");

			// }
			// var model = this.getOwnerComponent().getModel("oDataModel");
			// var currentRows = model.getProperty("/address");
			// var newRows = currentRows.concat(this.createEntry());
			// model.setProperty("/address", newRows);

		},
		createComm: function () {
			return {
				telephone: "",
				fax: "",
				standCommMethod: "",
				mobile: "",
				email: "",
				comments: "",
				extAddress: ""
			};
		},
		createIdent: function () {
			return {
				maritalStatus: "",
				occupation: "",
				countryOfOrigin: "",
				nationality: "",
				birthPlace: "",
				employer: "",
				personnelNo: "",
				uname: "",
				country: ""
			};
		},
		createEntry: function () {
			return {
				street: "",
				street2: "",
				street4: "",
				postalCode: "",
				city: "",
				country: "",
				email: "",
				telephone: "",
				emailState: "None",
				telephoneState: "None",
				streetState: "None",
				countryState: "None",
				postalCodeState: "None",
				cityState: "None"
			};
		},

		onPaymentPress: function () {
			var model = this.getOwnerComponent().getModel("oDataModel");
			var flag = this.fnCheckPayment();
			if (flag === 1) {
				var currentRows = model.getProperty("/payment");
				var newRows = currentRows.concat(this.createPaymentEntry());
				model.setProperty("/payment", newRows);
				console.log(model.getProperty("/payment"));
			}
			// else {
			// 	MessageToast.show("New Row can't be Added");
			// }
			// var model = this.getOwnerComponent().getModel("oDataModel");
			// var currentRows = model.getProperty("/payment");
			// var newRows = currentRows.concat(this.createPaymentEntry());
			// model.setProperty("/payment", newRows);

		},

		createPaymentEntry: function () {
			return {
				id: "",
				pCity: "",
				bankKey: "",
				bankAcct: "",
				controlKey: "",
				iban: "",
				refDoc: "",
				idState: "None",
				pCityState: "None",
				bankKeyState: "None",
				bankAcctState: "None",
				refDocState: "None"
			};
		},
		onSelect: function (oEvent) {
			console.log("In footer");
			var selectedTab = oEvent.getParameter("key");
			var bpIdDefault = "BP ID";
			var orderDefault = "Ascending";
			// console.log(selectedTab);
			selectedTab = parseInt(selectedTab);
			console.log(selectedTab);
			if (selectedTab === 2) {
				// this.getView().byId("footer").setVisible(false);

				this.getView().getModel("oSortModel").setProperty("/sSelectedKeySort", bpIdDefault);
				this.getView().getModel("oOrderModel").setProperty("/sSelectedKeyOrder", orderDefault);

				this.getView().byId("next").setVisible(true);
				this.getView().byId("previous").setVisible(true);
				this.getView().byId("footerText").setVisible(true);
				this.getView().byId("footerHbox1").setVisible(true);
				this.getView().byId("footerHbox2").setVisible(true);
				this.getView().byId("sub").setVisible(false);
				this.getView().byId("home1").setVisible(false);
				// this.getView().byId("nav").setVisible(true);
				this.fnPagination();
			} else {
				// this.getView().byId("footer").setVisible(true);

				this.getView().byId("next").setVisible(false);
				this.getView().byId("previous").setVisible(false);
				this.getView().byId("footerText").setVisible(false);
				this.getView().byId("footerHbox1").setVisible(false);
				this.getView().byId("footerHbox2").setVisible(false);
				this.getView().byId("sub").setVisible(true);
				this.getView().byId("home1").setVisible(true);
				// this.getView().byId("nav").setVisible(false);
			}

			// this.byId("footer").setVisible(false);
		},

		handleLinkPress: function (oEvent) {

			var oDataModel = this.getOwnerComponent().getModel("oDataModel");
			var path = oEvent.getSource().getText();
			var bpId = parseInt(path);

			var sFindAllUrl = "/Service_Lookups/find/findByBpId/" + bpId;
			BusyIndicator.show(0);
			$.ajax({
				url: sFindAllUrl,
				type: "GET",
				async: true,
				contentType: "application/json",

				success: function (results, status, response) {
					BusyIndicator.hide();
					console.log(results);
					oDataModel.setData(results);
					oDataModel.setProperty("/bpId", bpId);
					console.log(oDataModel);
				},
				error: function (e) {
					BusyIndicator.hide();
					console.log(e);
				}
			});

			this.getRouter().navTo("updateView");
			var oEditGlobalModel = this.getOwnerComponent().getModel("oEditGlobalModel");
			oEditGlobalModel.setProperty("/editProperty", false);
			oEditGlobalModel.setProperty("/enableProperty", false);
		},

		segFlag: 0,
		handleSegmentedButton: function (oEvent) {
			var selectedBtn = oEvent.getParameter("item").getText();
			if (selectedBtn === "Filter") {
				this.segFlag = 1;
				this.getView().byId("sortBox").setVisible(false);
				this.getView().byId("orderBox").setVisible(false);
				this.getView().byId("filterBox").setVisible(true);
				this.getView().byId("findBox").setVisible(false);
				this.getView().byId("searchBox").setVisible(false);
			} else if (selectedBtn === "Search") {
				this.segFlag = 2;
				this.getView().byId("sortBox").setVisible(false);
				this.getView().byId("orderBox").setVisible(false);
				this.getView().byId("filterBox").setVisible(true);
				this.getView().byId("findBox").setVisible(true);
				this.getView().byId("searchBox").setVisible(true);
			} else {
				this.segFlag = 0;
				this.getView().byId("sortBox").setVisible(true);
				this.getView().byId("orderBox").setVisible(true);
				this.getView().byId("filterBox").setVisible(false);
				this.getView().byId("findBox").setVisible(false);
				this.getView().byId("searchBox").setVisible(false);
			}

		},

		getDataFromSelectedRows: function (table, path) {
			return table.getSelectedIndices().map(function (index) {
				return table.getContextByIndex(index).getProperty(path);
			});
		}

	});
});