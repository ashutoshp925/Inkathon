sap.ui.define([
	"sap/m/MessageToast",
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/base/Log",
	"inc/inkt/od/ZMasterData/controller/BaseControllerUpdate",
	"../utility/formatter",
	"sap/ui/core/Fragment",
	"sap/ui/core/UIComponent",
	"sap/ui/core/routing/History",
	"sap/ui/core/BusyIndicator"
], function (MessageToast, Controller, JSONModel, Log, BaseControllerUpdate, formatter, Fragment, UIComponent, History, BusyIndicator) {
	"use strict";

	return BaseControllerUpdate.extend("inc.inkt.od.ZMasterData.controller.UpdateView", {
		formatter: formatter,
		myToken: "",
		onInit: function () {
			var that = this;
			that.fnValidateNull();
			var oJavaGlobalModel = this.getOwnerComponent().getModel("oJavaGlobalModel");
			var oDisplayGlobalModel = this.getOwnerComponent().getModel("oDisplayGlobalModel");
			var oDataModel = this.getOwnerComponent().getModel("oDataModel");
			console.log(oDataModel);

			var size = oDisplayGlobalModel.iSizeLimit;
			oDisplayGlobalModel.setSizeLimit(1000);
			oJavaGlobalModel.setSizeLimit(1000);
			var size1 = oDisplayGlobalModel.iSizeLimit;
			// console.log(size);
			// console.log(size1);
			// this.getView().byId("cancel").setVisible(false);
			// this.getView().byId("update").setVisible(false);
			// this.getView().byId("edit").setVisible(true);
			BusyIndicator.show(0);
			var sStdCommMethoUrl = "/Service_Lookups/api/standCommMethod";
			$.ajax({
				url: sStdCommMethoUrl,
				type: "GET",
				async: true,
				contentType: "application/json",
				headers: {
					"x-CSRF-Token": "Fetch"
				},
				success: function (results, status, response) {
					BusyIndicator.hide();
					// console.log(results);
					// oJavaGlobalModel.setProperty("/standCommMethod", results);
					// oUpdateGlobalModel.setProperty("/standCommMethod", results);
					// console.log(oJavaGlobalModel);
					// console.log(oUpdateGlobalModel);
					that.myToken = response.getResponseHeader("x-csrf-token");
					console.log(that.myToken);

				},
				error: function (e) {
					BusyIndicator.hide();
					console.log(e);
				}
			});
		},
		getRouter: function () {
			return UIComponent.getRouterFor(this);
		},
		onNavBack: function () {
			// this.getRouter().navTo("");
			this.getRouter().navTo("RouteHomeView");
			this.onReset();
			
			var oDataModel = this.getOwnerComponent().getModel("oDataModel");
			var oBasicData = {};
			var oAddress = [];
			var oPayment = [];
			var oCreateComm = this.createComm();
			var oIdentification = this.createIdent();

			oDataModel.setProperty("/basicDetails", oBasicData);
			oDataModel.setProperty("/address", oAddress);
			oDataModel.setProperty("/payment", oPayment);
			oDataModel.setProperty("/identifications", oIdentification);
			oDataModel.setProperty("/communications", oCreateComm);

			var oEditGlobalModel = this.getOwnerComponent().getModel("oEditGlobalModel");
			oEditGlobalModel.setProperty("/editProperty", true);
			oEditGlobalModel.setProperty("/enableProperty", true);

			this.getView().byId("cancel").setVisible(false);
			this.getView().byId("update").setVisible(false);
			this.getView().byId("edit").setVisible(true);
		},
		onPressOkayUpdate: function () {
			var that = this;
			this.getRouter().navTo("RouteHomeView");
			that._oDialog.close();
			that._oDialog.destroy();
			that._oDialog = null;
			this.getView().byId("cancel").setVisible(false);
			this.getView().byId("update").setVisible(false);
			this.getView().byId("edit").setVisible(true);
		},
		onPressOkayUpdateError: function () {
			var that = this;

			that._oDialog.close();
			that._oDialog.destroy();
			that._oDialog = null;
			this.getView().byId("cancel").setVisible(true);
			this.getView().byId("update").setVisible(true);
			this.getView().byId("edit").setVisible(false);
		},

		onChange: function (oEvent) {
			var sQuery = oEvent.getParameter("value");
			if (sQuery === "" || sQuery === undefined) {
				oEvent.getSource().setValueState(sap.ui.core.ValueState.Error); // if the field is empty after change, it will go red
			} else {
				oEvent.getSource().setValueState(sap.ui.core.ValueState.None); // if the field is not empty after change, the value state (if any) is removed
			}
		},
		onEdit: function (oEvent) {
			var oEditGlobalModel = this.getOwnerComponent().getModel("oEditGlobalModel");
			oEditGlobalModel.setProperty("/editProperty", true);
			oEditGlobalModel.setProperty("/enableProperty", true);
			this.getView().byId("cancel").setVisible(true);
			this.getView().byId("update").setVisible(true);
			this.getView().byId("edit").setVisible(false);
		},

		onUpdateBusinessPartner: function (oEvent) {
			var that = this;
			that.fnValidateNull();
			var oDataModel = this.getOwnerComponent().getModel("oDataModel");
			var addr = oDataModel.getProperty("/address");
			var pay = oDataModel.getProperty("/payment");

			var aAddr = [];
			for (var i = 0; i < addr.length; i++) {
				if (!(addr[i].street === "" && addr[i].street2 === "" && addr[i].street4 === "" && addr[i].postalCode === "" &&
						addr[i].city === "" && addr[i].country === "" && addr[i].email === "" && addr[i].telephone === "")) {
					aAddr.push(addr[i]);
				}
			}

			oDataModel.setProperty("/address", aAddr);

			var aPay = [];
			for (var j = 0; j < pay.length; j++) {
				if (!(pay[j].id === "" && pay[j].pCity === "" && pay[j].bankKey === "" && pay[j].bankAcct === "" && pay[j].controlKey === "" &&
						pay[j].iban === "" && pay[j].refDoc === "")) {
					aPay.push(pay[j]);
				}
			}
			oDataModel.setProperty("/payment", aPay);

			var postData = oDataModel.getData();
			console.log(postData);
			var sPostUrl = "/Service_Lookups/update/check";
			// Use Token
			var basicData = this.getView().getModel("oDataModel").getProperty("/basicDetails");

			var aError = [];
			var basic = "";
			var flag = 1;
			var flag1 = this.fnCheckCommunications();
			var flag2 = this.fnCheckIdentifications();
			var flag3 = this.fnCheckAddress();
			var flag4 = this.fnCheckPayment();
			if (flag3 === 2) {
				MessageToast.show(this.addrEmpty.join(" "));
			}
			if (flag4 === 2) {
				MessageToast.show(this.addrEmpty1.join(" "));
			}
			if (basicData.fname === undefined && basicData.lname === undefined && basicData.sTerm1 === undefined && basicData.sTerm2 ===
				undefined && basicData.sLanguage === undefined && basicData.sRole === undefined) {
				basic = "Basic Data is not Filled";
				MessageToast.show(basic);
				flag = 2;
			} else {

				if (basicData.fname === undefined || basicData.fname === "") {
					aError.push("First Name is not filled\r\n");

					flag = 0;
					this.getView().byId("fnIdUpdate").setValueState("Error");
				} else {
					this.getView().byId("fnIdUpdate").setValueState("None");
				}
				if (basicData.lname === undefined || basicData.lname === "") {
					aError.push("Last Name is not filled\r\n");
					flag = 0;
					this.getView().byId("lnIdUpdate").setValueState("Error");
				} else {
					this.getView().byId("lnIdUpdate").setValueState("None");
				}
				if (basicData.sTerm1 === undefined || basicData.sTerm1 === "") {
					aError.push("Search Term 1 is not filled\r\n");
					flag = 0;
					this.getView().byId("st1IdUpdate").setValueState("Error");
				} else {
					this.getView().byId("st1IdUpdate").setValueState("None");
				}
				if (basicData.sTerm2 === undefined || basicData.sTerm2 === "") {
					aError.push("Search Term 2 is not filled\r\n");
					flag = 0;
					this.getView().byId("st2IdUpdate").setValueState("Error");
				} else {
					this.getView().byId("st2IdUpdate").setValueState("None");
				}
				if (basicData.sLanguage === undefined || basicData.sLanguage === "") {
					aError.push("Language is not filled\r\n");
					flag = 0;
					this.getView().byId("langIdUpdate").setValueState("Error");
				} else {
					this.getView().byId("langIdUpdate").setValueState("None");
				}
				if (basicData.sRole === undefined || basicData.sRole === "") {
					aError.push("BP Role is not filled\r\n");
					flag = 0;
					this.getView().byId("brIdUpdate").setValueState("Error");
				} else {
					this.getView().byId("brIdUpdate").setValueState("None");
				}
				if (flag === 0) {
					MessageToast.show(aError.join(" "));
					//	oDataModel.setProperty("/basicDetails/error", "Error");
				}
			}
			console.log(oDataModel.getData());
			// BusyIndicator.show(0);
			if (flag === 1 && flag1 === 1 && flag2 === 1 && flag3 === 1 && flag4 === 1) {
				$.ajax({
					type: "POST",
					url: sPostUrl,
					data: JSON.stringify(postData),
					contentType: "application/json",
					dataType: "json",
					async: false,
					headers: {
						"X-CSRF-Token": this.myToken
					},
					success: function (data, status, response) {
						console.log(data);
						console.log(status);
						console.log(response);
						// MessageToast.show("Thank you Partner!! Business Partner with BP number " + data + " has been successfully created");
						oDataModel.setProperty("/BPnum", data);
						// BusyIndicator.hide();
						if (data.status === true) {
							if (!that._oDialog) {
								that._oDialog = sap.ui.xmlfragment("idAddItemFrag", "inc.inkt.od.ZMasterData.fragment.successDialogUpdate", that); // Instantiating the Fragment
							}
							that.getView().addDependent(that._oDialog);
							that._oDialog.open();
							that.onReset();
						} else {
							if (!that._oDialog) {
								that._oDialog = sap.ui.xmlfragment("idAddItemFrag", "inc.inkt.od.ZMasterData.fragment.errorDialogUpdate", that); // Instantiating the Fragment
							}
							that.getView().addDependent(that._oDialog);
							that._oDialog.open();
						}
					},
					error: function (error) {
						// BusyIndicator.hide();
						console.log(error);
						MessageToast.show("Connection Failed");
					}
				});
			}
			// this.onReset();
			var id = oDataModel.getProperty("/BPnum/role_id");
			// console.log(id)
			if (id >= 10000 && id <= 20000) {
				Fragment.byId("idAddItemFrag", "customer").setVisible(true);
			} else if (id >= 20001 && id <= 30000) {
				Fragment.byId("idAddItemFrag", "vendor").setVisible(true);
			}
			// console.log(id);

		},
		row: [],
		addrEmpty: [],
		fnCheckAddress: function () {
			console.log(this.row);
			this.fnValidateNull();
			var tableModel = this.getOwnerComponent().getModel("oDataModel");
			var tableData = tableModel.getProperty("/address");
			var lenAddress = tableData.length;
			console.log(lenAddress);
			tableModel.setProperty("/tableLength", lenAddress);
			while (this.row.length > 0) {
				this.row.pop();
			}
			while (this.addrEmpty.length > 0) {
				this.addrEmpty.pop();
			}
			console.log(this.row);
			var flag = 1;
			var e = "Error";
			var n = "None";
			var mailregex = /^([a-zA-Z0-9\.-_]+)@([a-zA-Z0-9-]+)\.([a-z]{2,15})(\.[a-z]{2,15})?$/;

			for (var i = 0; i < lenAddress; i++) {

				var cellStreetVal = tableData[i].street;
				var cellPostalVal = tableData[i].postalCode;
				var cellCityVal = tableData[i].city;
				var cellCountryVal = tableData[i].country;
				var cellEmailVal = tableData[i].email;
				var cellTelephoneVal = tableData[i].telephone;

				if (cellStreetVal === "" && cellPostalVal === "" && cellCityVal === "" && cellCountryVal ===
					"" && cellEmailVal === "" && cellTelephoneVal === undefined) {
					this.addrEmpty.push("Please fill the Required Field\r\n");
					flag = 2;
					break;
				} else {
					if (cellStreetVal === "" || cellStreetVal === undefined) {
						this.row.push(i + " Street is empty\r\n");

						tableModel.setProperty("/address/" + i + "/streetState", e);
						flag = 0;
					} else {
						tableModel.setProperty("/address/" + i + "/streetState", n);
					}
					if (cellPostalVal === "" || cellPostalVal === undefined) {
						this.row.push(i + " Postal Code is empty\r\n");
						tableModel.setProperty("/address/" + i + "/postalCodeState", e);
						flag = 0;
					} else {
						tableModel.setProperty("/address/" + i + "/postalCodeState", n);
					}
					if (cellCityVal === "" || cellCityVal === undefined) {
						this.row.push(i + " City is empty\r\n");
						tableModel.setProperty("/address/" + i + "/cityState", e);
						flag = 0;
					} else {
						tableModel.setProperty("/address/" + i + "/cityState", n);
					}
					if (cellCountryVal === "" || cellCountryVal === undefined) {
						this.row.push(i + " Country is empty\r\n");
						tableModel.setProperty("/address/" + i + "/countryState", e);
						flag = 0;
					} else {
						tableModel.setProperty("/address/" + i + "/countryState", n);
					}
					if (cellEmailVal === "" || cellEmailVal === undefined) {
						this.row.push(i + " Email is empty\r\n");
						tableModel.setProperty("/address/" + i + "/emailState", e);
						flag = 0;
					} else if (!mailregex.test(cellEmailVal)) {
						this.row.push(i + " Email is not in the right format\r\n");
						tableModel.setProperty("/address/" + i + "/emailState", e);
						flag = 0;
					} else {
						tableModel.setProperty("/address/" + i + "/emailState", n);
					}
					if (cellTelephoneVal === "" || cellTelephoneVal === undefined) {
						this.row.push(i + " Telephone is empty\r\n");
						tableModel.setProperty("/address/" + i + "/telephoneState", e);
						flag = 0;
					} else if (cellTelephoneVal.length > 10 && cellTelephoneVal.length < 0) {
						this.row.push(i + " Telephone number should be of 10 digit\r\n");
						tableModel.setProperty("/address/" + i + "/telephoneState", e);
						flag = 0;
					} else {
						tableModel.setProperty("/address/" + i + "/telephoneState", n);
					}
				}
			}
			if (flag === 0) {
				MessageToast.show(this.row.join(" "));
			}
			return flag;

		},
		row1: [],
		addrEmpty1: [],
		fnCheckPayment: function () {
            this.fnValidateNull();
			console.log(this.row1);

			var tableModel = this.getOwnerComponent().getModel("oDataModel");
			var tableData = tableModel.getProperty("/payment");
			var lenPayment = tableData.length;
			console.log(lenPayment);
			tableModel.setProperty("/paymentLength", lenPayment);
			while (this.row1.length > 0) {
				this.row1.pop();
			}
			while (this.addrEmpty1.length > 0) {
				this.addrEmpty1.pop();
			}
			console.log(this.row1);
			var flag = 1;
			var e = "Error";
			var n = "None";

			for (var i = 0; i < lenPayment; i++) {

				var cellIdVal = tableData[i].id;
				var cellPaymentCityVal = tableData[i].pCity;
				var cellBankKeyVal = tableData[i].bankKey;
				var cellBankAcctVal = tableData[i].bankAcct;

				if (cellIdVal === "" && cellPaymentCityVal === "" && cellBankKeyVal === "" && cellBankAcctVal ===
					undefined) {

					this.addrEmpty1.push("Please fill the Required Field\r\n");
					flag = 2;
					break;
				} else {
					if (cellIdVal === "" || cellIdVal === undefined) {
						this.row1.push(i + " ID is empty\r\n");

						tableModel.setProperty("/payment/" + i + "/idState", e);
						flag = 0;
					} else {
						tableModel.setProperty("/payment/" + i + "/idState", n);
					}
					if (cellPaymentCityVal === "" || cellPaymentCityVal === undefined) {
						this.row1.push(i + " City is empty\r\n");
						tableModel.setProperty("/payment/" + i + "/pCityState", e);
						flag = 0;
					} else {
						tableModel.setProperty("/payment/" + i + "/pCityState", n);
					}
					if (cellBankKeyVal === "" || cellBankKeyVal === undefined) {
						this.row1.push(i + " Bank Key is empty\r\n");
						tableModel.setProperty("/payment/" + i + "/bankKeyState", e);
						flag = 0;
					} else {
						tableModel.setProperty("/payment/" + i + "/bankKeyState", n);
					}
					if (cellBankAcctVal === "" || cellBankAcctVal === undefined) {
						this.row1.push(i + " Bank Account is empty\r\n");
						tableModel.setProperty("/payment/" + i + "/bankAcctState", e);
						flag = 0;
					} else {
						tableModel.setProperty("/payment/" + i + "/bankAcctState", n);
					}

				}

			}
			if (flag === 0) {
				MessageToast.show(this.row1.join(" "));
			}
			return flag;

		},
		fnCheckCommunications: function () {
			var aError = [];
			var flag = 1;
			var mailregex = /^([a-zA-Z0-9\.-_]+)@([a-zA-Z0-9-]+)\.([a-z]{2,15})(\.[a-z]{2,15})?$/;
			var mobileregex = /^[1-9]\d{9}$/;
			var commData = this.getOwnerComponent().getModel("oDataModel").getProperty("/communications");
			if (commData.comments === "" && commData.email === "" && commData.extAddress === "" && commData.fax === "" && commData.mobile ===
				"" && commData.standCommMethod === "" && commData.telephone === "") {
				flag = 1;
			} else {
				if (commData.mobile === undefined || commData.mobile === "") {
					aError.push("Mobile Number is not filled\r\n");

					flag = 0;
					this.getView().byId("mobId").setValueState("Error");
				} else if (!mobileregex.test(commData.mobile)) {
					aError.push("Mobile number is incorrect\r\n");
					this.getView().byId("mobId").setValueState("Error");
					flag = 0;
				} else {
					this.getView().byId("mobId").setValueState("None");
				}
				if (commData.standCommMethod === undefined || commData.standCommMethod === "") {
					aError.push("Communication method is not filled\r\n");

					flag = 0;
					this.getView().byId("cmId").setValueState("Error");
				} else {
					this.getView().byId("cmId").setValueState("None");
				}
				if (commData.extAddress === undefined || commData.extAddress === "") {
					aError.push("External address is not filled\r\n");

					flag = 0;
					this.getView().byId("extId").setValueState("Error");
				} else {
					this.getView().byId("extId").setValueState("None");
				}
				if (commData.email === undefined || commData.email === "") {
					aError.push("Email is not filled\r\n");

					flag = 0;
					this.getView().byId("mailId").setValueState("Error");
				} else if (!mailregex.test(commData.email)) {
					aError.push(" Email is not in the right format\r\n");
					this.getView().byId("mailId").setValueState("Error");
					flag = 0;
				} else {
					this.getView().byId("mailId").setValueState("None");
				}
			}

			if (flag === 0) {
				MessageToast.show(aError.join(" "));
			}
			return flag;
		},

		fnCheckIdentifications: function () {
			var aError = [];
			var flag = 1;
			var idenData = this.getOwnerComponent().getModel("oDataModel").getProperty("/identifications");

			if (idenData.birthPlace === "" && idenData.country === "" && idenData.countryOfOrigin === "" && idenData.employer === "" &&
				idenData.maritalStatus === "" && idenData.nationality === "" && idenData.occupation === "" && idenData.personnelNo === "" &&
				idenData.uname === "") {
				flag = 1;
			} else {
				if (idenData.occupation === undefined || idenData.occupation === "") {
					aError.push("Occupation is not chosen\r\n");
					flag = 0;
					this.getView().byId("occId").setValueState("Error");
				} else {
					this.getView().byId("occId").setValueState("None");
				}
				if (idenData.countryOfOrigin === undefined || idenData.countryOfOrigin === "") {
					aError.push("Country of Origin is not chosen\r\n");
					flag = 0;
					this.getView().byId("originId").setValueState("Error");
				} else {
					this.getView().byId("originId").setValueState("None");
				}
				if (idenData.nationality === undefined || idenData.nationality === "") {
					aError.push("Nationality is not chosen\r\n");
					flag = 0;
					this.getView().byId("natId").setValueState("Error");
				} else {
					this.getView().byId("natId").setValueState("None");
				}
				if (idenData.country === undefined || idenData.country === "") {
					aError.push("Citizenship is not chosen\r\n");
					flag = 0;
					this.getView().byId("citizenId").setValueState("Error");
				} else {
					this.getView().byId("citizenId").setValueState("None");
				}
			}
			if (flag === 0) {
				MessageToast.show(aError.join(" "));
			}
			return flag;
		},
		onPressOkay: function () {
			var that = this;
			that._oDialog.close();
			that._oDialog.destroy();
			that._oDialog = null;
		},
		onReset: function () {
			var oDataModel = this.getOwnerComponent().getModel("oDataModel");

			// var oBasicData = {};
			// var oBPnum = {};
			var oAddress = [];
			var oPayment = [];
			var oCreateComm = this.createComm();
			var oIdentification = this.createIdent();

			// oDataModel.setProperty("/basicDetails", oBasicData);
			oDataModel.setProperty("/address", oAddress);
			oDataModel.setProperty("/payment", oPayment);
			oDataModel.setProperty("/identifications", oIdentification);
			oDataModel.setProperty("/communications", oCreateComm);
			// oDataModel.setProperty("/BPnum", oBPnum);
			this.getView().byId("fnIdUpdate").setValueState("None");
			this.getView().byId("lnIdUpdate").setValueState("None");
			this.getView().byId("st1IdUpdate").setValueState("None");
			this.getView().byId("st2IdUpdate").setValueState("None");
			this.getView().byId("langIdUpdate").setValueState("None");
			this.getView().byId("brIdUpdate").setValueState("None");

			this.getView().byId("mobId").setValueState("None");
			this.getView().byId("cmId").setValueState("None");
			this.getView().byId("extId").setValueState("None");
			this.getView().byId("mailId").setValueState("None");
			this.getView().byId("occId").setValueState("None");
			this.getView().byId("originId").setValueState("None");
			this.getView().byId("natId").setValueState("None");
			this.getView().byId("citizenId").setValueState("None");

			console.log(oDataModel.getData());
		},
		showMore: function () {
			this.byId("showMoreUpdate").setVisible(false);
			this.byId("showLessUpdate").setVisible(true);
			this.byId("SplitAppDemoUpdate").setVisible(true);
		},
		showLess: function () {
			this.byId("showMoreUpdate").setVisible(true);
			this.byId("showLessUpdate").setVisible(false);
			this.byId("SplitAppDemoUpdate").setVisible(false);
		},

		onDeleteAddress: function (oEvent) {

			var rowPath = oEvent.getSource().getBindingContext("oDataModel").getPath();
			var path = rowPath + "";
			var index = path[path.length - 1];

			var tableModel = this.getOwnerComponent().getModel("oDataModel");
			var tableData = tableModel.getProperty("/address");
			tableData.splice(index, 1);
			tableModel.refresh();
			console.log(tableModel.getProperty("/address"));
		},
		onDeletePayment: function (oEvent) {
			var rowPath = oEvent.getSource().getBindingContext("oDataModel").getPath();
			var path = rowPath + "";
			var index = path[path.length - 1];

			// removing fromtable

			var tableModel = this.getOwnerComponent().getModel("oDataModel");
			var tableData = tableModel.getProperty("/payment");
			tableData.splice(index, 1);
			tableModel.refresh();
			console.log(tableModel.getProperty("/payment"));
		},
		onAddPress: function () {
			var model = this.getOwnerComponent().getModel("oDataModel");
			var flag = this.fnCheckAddress();
			if (flag === 1) {

				var currentRows = model.getProperty("/address");
				var newRows = currentRows.concat(this.createEntry());
				model.setProperty("/address", newRows);

			}

		},
		createComm: function () {
			return {
				telephone: "",
				fax: "",
				standCommMethod: "",
				mobile: "",
				email: "",
				comments: "",
				extAddress: ""
			};
		},
		createIdent: function () {
			return {
				maritalStatus: "",
				occupation: "",
				countryOfOrigin: "",
				nationality: "",
				birthPlace: "",
				employer: "",
				personnelNo: "",
				uname: "",
				country: ""
			};
		},
		createEntry: function () {
			return {
				street: "",
				street2: "",
				street4: "",
				postalCode: "",
				city: "",
				country: "",
				email: "",
				telephone: "",
				emailState: "None",
				telephoneState: "None",
				streetState: "None",
				countryState: "None",
				postalCodeState: "None",
				cityState: "None"
			};
		},

		onPaymentPress: function () {
			var model = this.getOwnerComponent().getModel("oDataModel");
			var flag = this.fnCheckPayment();
			if (flag === 1) {
				var currentRows = model.getProperty("/payment");
				var newRows = currentRows.concat(this.createPaymentEntry());
				model.setProperty("/payment", newRows);
				console.log(model.getProperty("/payment"));
			}

		},

		createPaymentEntry: function () {
			return {
				id: "",
				pCity: "",
				bankKey: "",
				bankAcct: "",
				controlKey: "",
				iban: "",
				refDoc: "",
				idState: "None",
				pCityState: "None",
				bankKeyState: "None",
				bankAcctState: "None"
			};
		},

		fnValidateNull: function () {
			var oDataModel = this.getOwnerComponent().getModel("oDataModel");

			var oAddress = [];
			var oPayment = [];
			var oCreateComm = this.createComm();
			var oIdentification = this.createIdent();

			var address = oDataModel.getProperty("/address");
			var payment = oDataModel.getProperty("/payment");
			var communications = oDataModel.getProperty("/communications");
			var identifications = oDataModel.getProperty("/identifications");

			if (address === null) {
				oDataModel.setProperty("/address", oAddress);
			}
			if (payment === null) {
				oDataModel.setProperty("/payment", oPayment);
			}
			if (communications === null) {
				oDataModel.setProperty("/communications", oCreateComm);
			}
			if (identifications === null) {
				oDataModel.setProperty("/identifications", oIdentification);
			}

		},

		getDataFromSelectedRows: function (table, path) {
			return table.getSelectedIndices().map(function (index) {
				return table.getContextByIndex(index).getProperty(path);
			});
		}

	});
});