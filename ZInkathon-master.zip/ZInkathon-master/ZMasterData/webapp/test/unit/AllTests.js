sap.ui.define([
	"inc/inkt/od/ZMasterData/test/unit/controller/HomeView.controller"
], function () {
	"use strict";
});