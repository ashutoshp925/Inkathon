# ZInkathon

Inkathon Project for Internship using SAP UI5 as FrontEnd and Java as Backend
