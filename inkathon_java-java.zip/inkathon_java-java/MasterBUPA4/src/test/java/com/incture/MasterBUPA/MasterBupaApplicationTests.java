package com.incture.MasterBUPA;

import org.junit.jupiter.api.Test;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MasterBupaApplicationTests {

	@Test
	void contextLoads() {
	}

}
