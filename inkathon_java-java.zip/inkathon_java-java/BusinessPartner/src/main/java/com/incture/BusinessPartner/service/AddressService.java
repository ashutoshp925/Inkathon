package com.incture.BusinessPartner.service;

import com.incture.BusinessPartner.entity.Address;


public interface AddressService {
	
	public void save(Address address);

}
